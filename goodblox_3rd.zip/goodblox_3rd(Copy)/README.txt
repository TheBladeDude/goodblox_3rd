# GOODBLOX 3RD
insecure source + emptied db

Please I recommended you not to revive Goodblox Like what i did
but yeah
if you skid your a skid then

heres guide for you
set up the emptied db
and go to google.com/recaptcha/admin to set up captcha
and yeah go fix the error by yourself

-thebladedude