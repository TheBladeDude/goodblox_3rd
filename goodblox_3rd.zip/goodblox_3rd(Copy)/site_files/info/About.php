<?php
include'../inc/header.php';
include'../inc/nav.php';
?>

  <title>GoodBlox: About Us</title>  
  <link rel="Shortcut Icon" type="image/ico" href="/favicon.ico" />
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta http-equiv="Content-Language" content="en-us" />
  <meta name="author" content="GoodBlox" />
  <meta name="description" content="GoodBlox is SAFE for gamers! GoodBlox is a FREE casual virtual world with fully constructible/desctructible 3D environments and immersive physics. Build, battle, chat, or just hang out." />
  <meta name="keywords" content="game, video game, building game, contstruction game, online game, LEGO game, LEGO, MMO, MMORPG, virtual world, avatar chat" />
  <meta name="robots" content="all">
  <meta name="theme-color" content="#FF0000" />
  <meta property="og:title" content="GoodBlox: About Us" />
  <meta property="og:site_name" content="GoodBlox - We're Good" />
  <meta property="og:url" content="https://goodblox.3d.tc" />
  <meta property="og:description" content="GoodBlox is SAFE for gamers! GoodBlox is a FREE casual virtual world with fully constructible/desctructible 3D environments and immersive physics. Build, battle, chat, or just hang out." />
  <meta property="og:type" content="website" />
  <meta property="og:image" content="https://goodblox.xyz/resources/goodblox128.png" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js" type="text/javascript"></script>
  <script data-ad-client="ca-pub-9428704937125405" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js" type="text/javascript"></script>

<h2>About Us</h2><big>
 <p>Goodblox is a revival project based on Roblox, an online-building and brick-battling gaming platform dedicated to the year 2009. We are a team of hardcore engineers with a passion for history and accuracy in everything we replicate. Our revival straddles several rapidly-developing aspects of internet entertainment: virtual worlds, casual gaming, and user-constructed content simulated during the 2009 years.</p>
 <p>Goodblox is free to play. Our revival remains under heavy development and is currently in serious beta testing. We deeply value community feedback as we continue to make Goodblox into a game that will excite the imagination of the young and the young at heart.</p>
 <p>For more information about Goodblox, visit the News and Help sections.</p>
 <p>For questions or comments, please contact us on our discord server which can be found <a href="https://discord.com/invite/KgYMa8eAqQ">here.</a></p>
 <p>Special thanks to:</p>
 <ul>
  <li>TheBladeDude</li>
  <li>Epic</li>
  <li>Zqzk</li>
  <li>Danyal Assi</li>
  <li>0lvt</li>
  <li>Yomi</li>
  <li>All staff, previous and current</li>
  <li>All contributors</li>
  <li>And many more</li>
 </ul>
 <p>Without these people, GoodBlox wouldn't be where it is at right now. Thank you all.</p>
</big>

<?php
  include_once'../inc/footer.php';
  ?>