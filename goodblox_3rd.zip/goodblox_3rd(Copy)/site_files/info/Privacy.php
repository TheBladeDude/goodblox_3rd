<?php
include'../inc/header.php';
include'../inc/nav.php';
?>

  <title>GoodBlox: Privacy</title>  
  <link rel="Shortcut Icon" type="image/ico" href="/favicon.ico" />
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta http-equiv="Content-Language" content="en-us" />
  <meta name="author" content="GoodBlox" />
  <meta name="description" content="GoodBlox is SAFE for gamers! GoodBlox is a FREE casual virtual world with fully constructible/desctructible 3D environments and immersive physics. Build, battle, chat, or just hang out." />
  <meta name="keywords" content="game, video game, building game, contstruction game, online game, LEGO game, LEGO, MMO, MMORPG, virtual world, avatar chat" />
  <meta name="robots" content="all">
  <meta name="theme-color" content="#FF0000" />
  <meta property="og:title" content="GoodBlox: Privacy" />
  <meta property="og:site_name" content="GoodBlox - We're Good" />
  <meta property="og:url" content="https://goodblox.3d.tc" />
  <meta property="og:description" content="GoodBlox is SAFE for gamers! GoodBlox is a FREE casual virtual world with fully constructible/desctructible 3D environments and immersive physics. Build, battle, chat, or just hang out." />
  <meta property="og:type" content="website" />
  <meta property="og:image" content="https://goodblox.xyz/resources/goodblox128.png" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js" type="text/javascript"></script>
  <script data-ad-client="ca-pub-9428704937125405" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js" type="text/javascript"></script>

<br clear="all"/>
<p>
    <b>GoodBlox Privacy Policy</b>
</p>
<p>
    <b>I. The Information We Collect </b>
    <br/>
    <br/>
    At GoodBlox, the only personally identifiable information we collect is a valid e-mail address. We do not share this information with anybody else.
</p>
<p>
    Additionally, when visitors come to our site, we automatically collect some non-personally identifiable "computer" information, such as the type of computer operating system (e.g., Windows 95 or Mac OS), the web browser (e.g., Netscape, Internet Explorer) being used, and information regarding the Internet service provider.
</p>
<p>
    Finally, we collect performance data from within GoodBlox Studio or the GoodBlox Player. We use this data retrospectively to improve the user experience of our games. This information includes in-game networking activity, CPU load, and resource usage, among other relevant data.
</p>
<p></p>
<p>
    <b>II. How We Use the Information</b>
    <br/>
    <br/>
    We use visitors' personal information only for our internal purposes of enabling visitors to log in to our site, to reset passwords, or to inform users of upcoming events and special announcements.
    <br/>
    <br/>
    We sometimes use the non-personally identifiable information that we collect to improve the design and content of our site and&nbsp;to personalize our visitors' experience on GoodBlox. We also may use this information in the aggregate to analyze site usage.
    <br/>
    <br/>
    We will disclose information we maintain when required to do so by law, for example, in response to a court order or a subpoena. We also may disclose such information in response to a law enforcement agency's request.
    <br/>
    <br/>
    We will not use or transfer personally identifiable information in ways that are materially different from the ones described above without also providing parental notification of such practices and obtaining consent for any materially different uses.
    <br/>
    <br/>
    <b>III. Cookies</b><br/>
    <br/>
    GOODBLOX uses a software technology called "cookies." Cookies are small text files that we place in visitors' computer browsers to store their preferences. Cookies themselves do not contain any personally identifiable information.
    <br/>
    <br/>
    <b>IV. Contact Us</b><br/>
    <br/>
    If you have any questions, comments, or concerns regarding our privacy policy and/or practices, please contact us at the following e-mail address. Additionally, you can contact us on our discord <a href="https://discord.gg/DdTsmyB">here.</a>
    <br/>
    <br/>
    <a href="mailto:goodbloxxxxxx@protonmail.com">goodbloxxxxxx@protonmail.com</a>
    <br/>
</p>

<?php  
  include_once'../inc/footer.php';
  ?>