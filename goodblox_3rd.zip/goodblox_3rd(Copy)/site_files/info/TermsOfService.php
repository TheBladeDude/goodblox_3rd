<?php
include'../inc/header.php';
include'../inc/nav.php';
?>


  <title>GoodBlox: Terms Of Service</title>  
  <link rel="Shortcut Icon" type="image/ico" href="/favicon.ico" />
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta http-equiv="Content-Language" content="en-us" />
  <meta name="author" content="GoodBlox" />
  <meta name="description" content="GoodBlox is SAFE for gamers! GoodBlox is a FREE casual virtual world with fully constructible/desctructible 3D environments and immersive physics. Build, battle, chat, or just hang out." />
  <meta name="keywords" content="game, video game, building game, contstruction game, online game, LEGO game, LEGO, MMO, MMORPG, virtual world, avatar chat" />
  <meta name="robots" content="all">
  <meta name="theme-color" content="#FF0000" />
  <meta property="og:title" content="GoodBlox: Terms Of Service" />
  <meta property="og:site_name" content="GoodBlox - We're Good" />
  <meta property="og:url" content="https://goodblox.3d.tc" />
  <meta property="og:description" content="GoodBlox is SAFE for gamers! GoodBlox is a FREE casual virtual world with fully constructible/desctructible 3D environments and immersive physics. Build, battle, chat, or just hang out." />
  <meta property="og:type" content="website" />
  <meta property="og:image" content="https://goodblox.xyz/resources/goodblox128.png" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js" type="text/javascript"></script>
  <script data-ad-client="ca-pub-9428704937125405" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js" type="text/javascript"></script>
 </head>


<p>It is very important that you review the 
following rules so that you know what you can and cannot do on GOODBLOX. By using 
this site, you and your parents agree to abide by the following terms and 
conditions:</p>
<div style="text-align:center">
  <div style="border:3px solid black">
   <div style="text-align:left;margin-left:5px">
        <div style="margin-top:3px;margin-bottom:3px">
            <li>You must be <strong>13 years of age or older</strong> to use or register for GOODBLOX.</li>
        </div>
        <div style="margin-top:3px;margin-bottom:3px">
            <li>GOODBLOX is not responsible for user generated content or actions.</li>
        </div>
        <div style="margin-top:3px;margin-bottom:3px">
            <li>Do not scrape, fuzz, or otherwise bruteforce GOODBLOX's web services.</li>
        </div>
        <div style="margin-top:3px;margin-bottom:3px">
            <li>You are not allowed to modify, distribute, or take advantage of any code distributed within GOODBLOX. (including exploiting).</li>
        </div>
    <div style="margin-top:3px;margin-bottom:3px">
    <li>You are not allowed to spam or flood the site with requests.</li>
    </div>
    <div style="margin-top:3px;margin-bottom:3px">
    <li>Do not create new accounts to circumvent moderation actions, of any type,  against your account.</li>
    </div>
    <div style="margin-top:3px;margin-bottom:3px">
    <li>You must not engage in, or endorse, unlawful content shared through the GOODBLOX service. This namely includes copyright.</li>
    </div>
    <div style="margin-top:3px;margin-bottom:3px">
    <li>You must not share your account details, as compromised accounts will not be compensated for.</li>
    </div>
    <div style="margin-top:3px;margin-bottom:3px">
    <li>All donations are final. If you donate, refunds will not be issued, under any circumstances.</li>
    </div>
    <div style="margin-top:3px;margin-bottom:3px">
    <li>Profanities, expletives ("swear words") and such inappropriate activies are prohibited.</li>
    </div>
    <div style="margin-top:3px;margin-bottom:3px">
    <li>We have a zero tolerance harassment policy. Do not do it.</li>
    </div>
    <div style="margin-top:3px;margin-bottom:3px">
    <li>NSFW content is strictly prohibited. We take this very seriously.</li>
    </div>
    <div style="margin-top:3px;margin-bottom:3px">
    <li>If you would like to send legal requests such as DMCA requests, Cease and Desist & other legal notices, please email <a href="mailto:goodbloxxxxxx@protonmail.com">goodbloxxxxxx@protonmail.com</a></li>
    </div>
    <div style="margin-top:3px;margin-bottom:3px">
    <li>All content on-site is property of GOODBLOX, and is owned as such unless owned by another identity. You are not allowed to re-use it for your own work.</i>
    </div>
   </div>
  </div>
</div>
      
<?php  
  include_once'../inc/footer.php';
  ?>