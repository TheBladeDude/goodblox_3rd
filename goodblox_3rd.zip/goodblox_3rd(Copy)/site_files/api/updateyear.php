<?php

require_once $_SERVER["DOCUMENT_ROOT"] . "/inc/config.php";

$currentid = $_USER['id']; 

if (isset($_POST["render_choice"])) {
    $stmt_fetch_render_choice = $conn->prepare("SELECT is_render_1 FROM users WHERE id=:id");
    $stmt_fetch_render_choice->bindParam(':id', $currentid);
    $stmt_fetch_render_choice->execute();
    $current_render_choice = $stmt_fetch_render_choice->fetchColumn();

    $new_render_choice = ($current_render_choice == 1) ? 0 : 1;
    $sql = "UPDATE users SET is_render_1=:render_choice WHERE id=:id";

    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':render_choice', $new_render_choice);
    $stmt->bindParam(':id', $currentid); // Bind $currentid to the parameter :id

    if ($stmt->execute()) {
        echo "<span style='color: green; font-family: verdana'>Successfully updated character</span>";
        echo "<script>window.history.back()</script>";
    } else {
        echo "Error: " . $conn->errorInfo()[2]; 
    }
}

header("location: render.aspx"); 
?>
