<?php

require_once($_SERVER['DOCUMENT_ROOT']."/inc/config.php");
$id = (int) addslashes($_GET["id"]);
$userl = $conn->query("SELECT * FROM users WHERE id = '$id'")->fetch(PDO::FETCH_ASSOC);
  //header('Content-type:image/png');
echo '<img src="data:image/gif;base64,' . $userl['thumbnail'] . '" width="170" height="170" / >';

  
  /*
require_once($_SERVER['DOCUMENT_ROOT']."/inc/db.php");

$id = (int) $_GET["id"];

$stmt = $conn->prepare("SELECT thumbnail FROM users WHERE id = ?");
$stmt->execute([$id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

header('Content-type: image/png');

echo base64_decode($user['thumbnail']);
    */
?>
