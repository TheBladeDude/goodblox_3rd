<?php include '../inc/header.php'; ?>
<?php include '../inc/nav.php'; ?>
<html>
<p><?=$sitename?> Help:</p>
<ul>
<li><a href="hostinghelp.aspx">[Hosting a game]</a></li>
<li><a href="build.aspx">[Building a game]</a></li>
</ul>
</html>