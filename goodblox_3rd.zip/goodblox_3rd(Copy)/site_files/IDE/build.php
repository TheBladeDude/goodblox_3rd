<?php include '../inc/header.php'; ?>
<?php include '../inc/nav.php'; ?>
<html>
<p>To start building a game click on [File] and after [New] and to have the toolbox click on [View] and [ToolBox]</p>
<li><a href="Landing.php"> [Go Back] </a></li>
</html>