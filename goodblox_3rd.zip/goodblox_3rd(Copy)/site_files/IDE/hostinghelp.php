<?php include '../inc/header.php'; ?>
<?php include '../inc/nav.php'; ?>
<html>
<p>To host a GoodBlox Game, go to the main website and click on [your game] and then click on [host] after that specify where the map is and the filename.</p>
<li><a href="Landing.php"> [Go Back] </a></li>
</html>
