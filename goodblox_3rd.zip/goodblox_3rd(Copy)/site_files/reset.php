<?php
session_start();

if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) {
    header("location: /");
    exit;
}

require_once $_SERVER["DOCUMENT_ROOT"] . "/inc/config.php";
  
header("location: /");
?>
<?php
include 'inc/header.php';
include 'inc/nav.php';
?>
