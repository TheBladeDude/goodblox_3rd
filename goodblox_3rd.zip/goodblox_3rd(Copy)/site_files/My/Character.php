<?php
include $_SERVER["DOCUMENT_ROOT"].'/inc/header.php';
include $_SERVER["DOCUMENT_ROOT"].'/inc/nav.php';
require_once $_SERVER["DOCUMENT_ROOT"].'/inc/config.php';
if($isloggedin !== 'yes') {header('location: /login.aspx');}
$querytype = htmlspecialchars($_GET["wtype"]);

$colors = [
    "24" => "Br. yellowish green",
    "106" => "Bright yellow",
    "21" => "Bright orange",
    "22" => "Bright red", 
    "106" => "Bright violet", 
    "23" => "Bright blue",
    "107" => "Bright bluish green",
    "37" => "Bright green",
    "1001" => "Institutional white",
    "1" => "White",
    "208" => "Light stone grey",
    "1002" => "Mid gray",
    "194" => "Medium stone grey",
    "199" => "Dark stone grey",
    "26" => "Black",
    "1003" => "Really black",
    "1022" => "Grime",
    "105" => "Br. yellowish orange",
    "125" => "Light orange",
    "153" => "Sand red",
    "1023" => "Lavender",
    "135" => "Sand blue",
    "102" => "Medium blue",
    "151" => "Sand green",
    "5" => "Brick yellow",
    "226" => "Cool yellow",
    "133" => "Neon orange",
    "101" => "Medium red",
    "9" => "Light reddish violet",
    "11" => "Pastel Blue",
    "1018" => "Teal",
    "29" => "Medium green",
    "1030" => "Pastel brown",
    "1029" => "Pastel yellow",
    "1025" => "Pastel orange",
    "1016" => "Pink",
    "1026" => "Pastel violet",
    "1024" => "Pastel light blue",
    "1027" => "Pastel blue-green",
    "1028" => "Pastel green",
    "1008" => "Olive",
    "1009" => "New Yeller",
    "1005" => "Deep orange",
    "1004" => "Really red",
    "1032" => "Hot pink",
    "1010" => "Really blue",
    "1019" => "Toothpaste",
    "1020" => "Lime green",
    "217" => "Brown",
    "18" => "Nougat",
    "38" => "Dark orange",
    "1031" => "Royal purple",
    "1006" => "Alder",
    "1013" => "Cyan",
    "45" => "Light blue",
    "1021" => "Camo",
    "192" => "Reddish brown",
    "1014" => "CGA brown",
    "1007" => "Dusty Rose",
    "1015" => "Magenta",
    "1012" => "Deep blue",
    "1011" => "Navy blue",
    "28" => "Dark green",
    "141" => "Earth green"
];
$colorHexMap = [
    "24" => "#D3C670", // Br. yellowish green
    "106" => "#FFD700", // Bright yellow
    "21" => "#FFA500", // Bright orange
    "22" => "#FF0000", // Bright red
    "23" => "#0000FF", // Bright blue
    "107" => "#00FF00", // Bright bluish green
    "37" => "#00FF00", // Bright green
    "1001" => "#F8F8FF", // Institutional white
    "1" => "#FFFFFF", // White
    "208" => "#B0B0B0", // Light stone grey
    "1002" => "#808080", // Mid gray
    "194" => "#787878", // Medium stone grey
    "199" => "#555555", // Dark stone grey
    "26" => "#000000", // Black
    "1003" => "#000000", // Really black
    "1022" => "#545454", // Grime
    "105" => "#FFA500", // Br. yellowish orange
    "125" => "#FFA07A", // Light orange
    "153" => "#DAA520", // Sand red
    "1023" => "#E6E6FA", // Lavender
    "135" => "#4682B4", // Sand blue
    "102" => "#0000CD", 
    "151" => "#8FBC8F", 
    "5" => "#FFD351", // 
    "226" => "#FFFF00", 
    "133" => "#FFA500", 
    "101" => "#FF0000", 
    "9" => "#FFC0CB", 
    "11" => "#ADD8E6", // Pastel Blue
    "1018" => "#008080", // Teal
    "29" => "#00FF00", // Medium green
    "1030" => "#964B00", // Pastel brown
    "1029" => "#FFFF00", // Pastel yellow
    "1025" => "#FFA500", // Pastel orange
    "1016" => "#FFC0CB", // Pink
    "1026" => "#D8BFD8", // Pastel violet
    "1024" => "#B0E0E6", // Pastel light blue
    "1027" => "#87CEEB", // Pastel blue-green
    "1028" => "#77DD77", // Pastel green
    "1008" => "#808000", // Olive
    "1009" => "#FFFF00", // New Yeller
    "1005" => "#FF4500", // Deep orange
    "1004" => "#FF0000", // Really red
    "1032" => "#FF69B4", // Hot pink
    "1010" => "#0000FF", // Really blue
    "1019" => "#87CEEB", // Toothpaste
    "1020" => "#32CD32", // Lime green
    "217" => "#A52A2A", // Brown
    "18" => "#FFE4B5", // Nougat
    "38" => "#FF8C00", // Dark orange
    "1031" => "#800080", // Royal purple
    "1006" => "#8B4513", // Alder
    "1013" => "#00FFFF", // Cyan
    "45" => "#ADD8E6", // Light blue
    "1021" => "#78866B", // Camo
    "192" => "#8B4513", // Reddish brown
    "1014" => "#A52A2A", // CGA brown
    "1007" => "#FF7F50", // Dusty Rose
    "1015" => "#FF00FF", 
    "1012" => "#00008B", // Deep blue
    "1011" => "#000080", // Navy blue
    "28" => "#006400", // Dark green
    "141" => "#228B22", 
];

function getColorCode($colorNumber) {
    global $colorHexMap;
    return isset($colorHexMap[$colorNumber]) ? $colorHexMap[$colorNumber] : "#808080"; 
}

function generateSelect($id, $name, $selectedValue, $options)
{
    $select = "<select id='$id' name='$name'>";
    foreach ($options as $value => $color) {
        $selected = ($value == $selectedValue) ? "selected" : "";
        $colorCode = getColorCode($value);
        $select .= "<option class='color-preview' value='$value' $selected style='background-color:$colorCode;'>$color</option>";
    }
    $select .= "</select>";
    return $select;
}

$selectedColor = [
    "head" => $_USER["headcolor"],
    "larm" => $_USER["leftarmcolor"],
    "rarm" => $_USER["rightarmcolor"],
    "torso" => $_USER["torsocolor"],
    "lleg" => $_USER["leftlegcolor"],
    "rleg" => $_USER["rightlegcolor"]
];

$headSelect = generateSelect("head", "head", $selectedColor["head"], $colors);
$larmSelect = generateSelect("larm", "larm", $selectedColor["larm"], $colors);
$rarmSelect = generateSelect("rarm", "rarm", $selectedColor["rarm"], $colors);
$torsoSelect = generateSelect("torso", "torso", $selectedColor["torso"], $colors);
$llegSelect = generateSelect("lleg", "lleg", $selectedColor["lleg"], $colors);
$rlegSelect = generateSelect("rleg", "rleg", $selectedColor["rleg"], $colors);

?>
<div id="Body">
    <style>

  .clothe
  {
    width:110px;
    /*height: 200px;*/
    margin: 10px;
    text-align: left;
    
    vertical-align: top;
    display: inline-block;
    display: -moz-inline-stack;
    *display: inline;
  }
  .clothe .name {
    font-weight: bold;
  }
  .nocl
  {
    font-family: Verdana;
    font-weight: bold;
    text-align: center;
  }
  .img{
    border:none;
    height: 100%;
  }
  .imgc
  {
    border:1px solid black;
    width: 110px;
    height: 110px;
    text-align: center;
    padding: 10px;
    position: relative;
  }
  .fixed
  {
    position:absolute;
    right:0;
    top:0;
    background-color: #EEEEEE;
    border: 1px solid #555555;
    color: blue;
    font-family: Verdana;
    font-size: 10px;
    font-weight: lighter;
  }
  #left{
    width: 69%;
    float: left;
  }
  #right{
    width: 30%;
    float: right;
  }
  #Body table
  {
    border: 1px black solid;
  }
  .tablehead
  {
    font-size:16px; font-weight: bold; border-bottom:black 1px solid; width: 100%; background-color: #CCCCCC; color: #222222;
  }
  .tablebody
  {
    font-weight: lighter; background-color: transparent;font-family: Verdana;
  }
  .margin{
    margin:10px;
  }
  .clickable, .clickable3, .clickable2
  {
    border: none;
    margin:1px;
  }
  .clickable{
    width:50px;
    height: 50px;
  }
  .clickablesm{
    width:40px;
    height:40px;
    margin:5px;
  }
  .clickable2{
    width:47px;
    height: 100px;
  }
  .clickable3{
    width:100px;
    height: 100px;
  }
  .nonsbtn
  {
    font-weight:normal;
  }
  #col{
    position: fixed;
    top: 50%;
    left: 50%;
    margin-top: -105px;
    margin-left: -205px;
    width: 410px;
    height: 210px;
    z-index: 498;
    background-color: white;
    text-align: center;
    vertical-align: center;
  }
  .tablebody a {
      color:blue;
  }
  .tablebody a:hover {
      cursor:pointer;
  }
#left {
    width: 69%;
    float: left;
}
.clickable2 {
    width: 47px;
    height: 100px;
}
.clickable3 {
    width: 100px;
    height: 100px;
}
#right {
    width: 30%;
    float: right;
}
.tablebody {
    font-weight: lighter;
    background-color: transparent;
    font-family: Verdana;
}
.clickable {
    width: 50px;
    height: 50px;
}
.clickable, .clickable3, .clickable2 {
    border: none;
    margin: 1px;
}
#Body table {
    border: 1px black solid;
}
.tablehead {
    font-size: 16px;
    font-weight: bold;
    border-bottom: black 1px solid;
    width: 100%;
    background-color: #CCCCCC;
    color: #222222;
        #left {
    width: 69%;
    float: left;
}
.clickable2 {
    width: 47px;
    height: 100px;
}
.clickable3 {
    width: 100px;
    height: 100px;
}
#right {
    width: 30%;
    float: right;
}
.tablebody {
    font-weight: lighter;
    background-color: transparent;
    font-family: Verdana;
}
.clickable {
    width: 50px;
    height: 50px;
}
.clickable, .clickable3, .clickable2 {
    border: none;
    margin: 1px;
}

</style>
  <script>
  $(document).ready(function () {
    function loadContent(wtype) {
      history.pushState(null, null, '/My/Character.aspx?wtype=' + wtype);

      $.ajax({
        url: '/api/user/getwardrobe.php',
        type: 'GET',
        data: { wtype: wtype },
        success: function (responseData) {
          $('#wardrobe').html(responseData);
        },
        error: function (xhr, status, error) {
          console.error('Error:', error);
        }
      });
    }

    // Function to handle link click
    function handleLinkClick(link, wtype) {
      $('.tablebody a').removeClass('bold');
      link.addClass('bold');
      loadContent(wtype);
    }

    $(document).ready(function () {
      handleLinkClick($('#btn7'), 'hat');
    });

    $(document.body).on('click', '#btn2', function (e) {
      e.preventDefault();
      handleLinkClick($('#btn2'), 'tshirt');
    });

    $(document.body).on('click', '#btn5', function (e) {
      e.preventDefault();
      handleLinkClick($('#btn5'), 'shirt');
    });

    $(document.body).on('click', '#btn6', function (e) {
      e.preventDefault();
      handleLinkClick($('#btn6'), 'pants');
    });

    $(document.body).on('click', '#btn7', function (e) {
      e.preventDefault();
      handleLinkClick($('#btn7'), 'hat');
    });

    $(document.body).on('click', '#btn8', function (e) {
      e.preventDefault();
      handleLinkClick($('#btn8'), 'face');
    });

    $(document.body).on('click', '#btn9', function (e) {
      e.preventDefault();
      handleLinkClick($('#btn9'), 'head');
    });
  });
</script>
<div id="left">
  <table cellspacing="0px" width="100%" style="margin-bottom:10px;">
    <tbody><tr>
        <th class="tablehead">My Wardrobe</th>
    </tr>
    <tr>
        <?php
        echo"
        <td class=\"tablebody\" style=\"font-size:12px; text-align: center; border-bottom: 1px solid black;\">
        ";
        if($querytype == "tshirt") {
        echo"<a id=\"btn2\" href=\"/My/Character.aspx?wtype=tshirt\" style=\"font-weight: bold;\">T-Shirts</a>";
        }else{
        echo"<a id=\"btn2\" href=\"/My/Character.aspx?wtype=tshirt\">T-Shirts</a>";
        }
        if($querytype == "shirt") {
        echo"             |             <a id=\"btn5\" href=\"/My/Character.aspx?wtype=shirt\" style=\"font-weight: bold;\">Shirts</a>";
        }else{
        echo"             |             <a id=\"btn2\" href=\"/My/Character.aspx?wtype=shirt\">Shirts</a>";
        }
        if($querytype == "pants") {
        echo"             |             <a id=\"btn5\" href=\"/My/Character.aspx?wtype=pants\" style=\"font-weight: bold;\">Pants</a>";
        }else{
        echo"             |             <a id=\"btn2\" href=\"/My/Character.aspx?wtype=pants\">Pants</a>";
        }
        if($querytype == "hat") {
        echo"             |             <a id=\"btn5\" href=\"/My/Character.aspx?wtype=hat\" style=\"font-weight: bold;\">Hats</a>";
        }else{
        echo"             |             <a id=\"btn2\" href=\"/My/Character.aspx?wtype=hat\">Hats</a>";
        }
        if($querytype == "face") {
        echo"             |             <a id=\"btn5\" href=\"/My/Character.aspx?wtype=face\" style=\"font-weight: bold;\">Faces</a>";
        }else{
        echo"             |             <a id=\"btn2\" href=\"/My/Character.aspx?wtype=face\">Faces</a>";
          
        }
        if($querytype == "head") {
        echo"             |             <a id=\"btn5\" href=\"/My/Character.aspx?wtype=head\" style=\"font-weight: bold;\">Heads</a>";
        }else{
        echo"             |             <a id=\"btn2\" href=\"/My/Character.aspx?wtype=head\">Heads</a>";
          
        }
        echo"
        <br><a href=\"/catalog.aspx\">Shop</a>
        </td>";
        ?>
    </tr>
    <tr>
        <td class="tablebody">
            <div id="wardrobe" style="padding-left:13px;">
                  <?php
$stmt = $conn->prepare("SELECT * FROM owned_items WHERE ownerid = :ownerid AND type = :querytype");
$stmt->execute(array(':ownerid' => $_USER["id"], ':querytype' => $querytype));
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $stmt2 = $conn->prepare("SELECT * FROM catalog WHERE id = :itemid");
    $stmt2->execute(array(':itemid' => $row['itemid']));
    $item = $stmt2->fetch(PDO::FETCH_ASSOC);

    $thumburl = $item['thumbnail'];

    $stmt3 = $conn->prepare("SELECT * FROM users WHERE id = :creatorid");
    $stmt3->execute(array(':creatorid' => $item['creatorid']));
    $user = $stmt3->fetch(PDO::FETCH_ASSOC);

    $id = htmlspecialchars($row['assetid']);
    $name = htmlspecialchars($item['name']);
    $creator = htmlspecialchars($user['username']);
  
    if($item['type'] == "hat"){
      $itemtype = "Hat";
    }
    if($item['type'] == "pants"){
      $itemtype = "Pants";
    }
    if($item['type'] == "shirt"){
      $itemtype = "Shirt";
    }
    if($item['type'] == "face"){
      $itemtype = "Face";
    }
    if($item['type'] == "tshirt"){
      $itemtype = "T-Shirt";
    }

    echo "<div class='clothe' style='font-size:10.85px; display:inline-block; *display:inline; margin:5px; display: inline-block; display: -moz-inline-stack; *display: inline; vertial-align:top;'>
        <div id='$name' class='imgc' style='cursor:pointer;'><img class='img' src='$thumburl'>
            <div class='fixed'><a href=\"/My/characterwear.aspx?id=".$item['id']."&wtype=".$querytype."\">[ wear ]</a></div>
        </div>
        <a class='name' href='/catalog.aspx'>$name</a><br>
        Type: ".$itemtype."<br>
        Creator: <a href='/user/?id={$item['creator']}'>$creator</a>
    </div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
}

$stmt4 = $conn->prepare("SELECT * FROM owned_items WHERE ownerid = :ownerid AND type = :querytype");
$stmt4->execute(array(':ownerid' => $_USER["id"], ':querytype' => $querytype));
                   
    
          
                                    
     ?>
              <?php
       if(is_null($_GET["wtype"])) {
    echo"<tr>
        <td class='tablebody'>
            <div id='wardrobe' style='padding-left:13px;'>Please select a category.</div>
        <div style='clear:both;'></div>
      </td>
    </tr>";
      }
    
                                  ?>
               
                                  
                                            </div>
        <div style="clear:both;"></div>
      </td>
    </tr>
  </tbody></table><div class="seperator"></div>
  <table cellspacing="0px" width="100%">
    <tbody><tr>
        <th class="tablehead">Currently Wearing</th>
    </tr>
  </tbody><tbody><tr>
  <th class="tablebody">
  <?php
$itemsq = $conn->prepare("SELECT * FROM wearing WHERE userid=:user_id");
$itemsq->bindParam(':user_id', $_USER['id'], PDO::PARAM_INT);
$itemsq->execute();

while($row = $itemsq->fetch(PDO::FETCH_ASSOC)) {
    $itemq = $conn->prepare("SELECT * FROM catalog WHERE id=:item_id");
    $itemq->bindParam(':item_id', $row['itemid'], PDO::PARAM_INT);
    $itemq->execute();
    $item = $itemq->fetch(PDO::FETCH_ASSOC);
    $thumburl = $item['thumbnail'];
    
    $iteml = $conn->prepare("SELECT * FROM users WHERE id=:creator_id");
    $iteml->bindParam(':creator_id', $item['creatorid'], PDO::PARAM_INT);
    $iteml->execute();
    $user = $iteml->fetch(PDO::FETCH_ASSOC);
    
    $id = htmlspecialchars($row['assetid']);
    $name = htmlspecialchars($item['name']);
    $creator = htmlspecialchars($user['username']);
  
    if($item['type'] == "hat"){
      $itemtype = "Hat";
    }
    if($item['type'] == "pants"){
      $itemtype = "Pants";
    }
    if($item['type'] == "shirt"){
      $itemtype = "Shirt";
    }
    if($item['type'] == "face"){
      $itemtype = "Face";
    }
    if($item['type'] == "tshirt"){
      $itemtype = "T-Shirt";
    }
    
    echo "<div class='clothe' style='font-size:10.85px; display:inline-block; *display:inline; margin:5px; display: inline-block; display: -moz-inline-stack; *display: inline; vertial-align:top;'>
        <div id='".$name."' class='imgc' style='cursor:pointer;'><img class='img' src='".$thumburl."'>
            <div class='fixed'><a href=\"/My/characterremove.aspx?id=".$item['id']."&wtype=".$querytype."\">[ remove ]</a></div>
        </div>
        <a class='name' href='/item.aspx?id=".$id."'>".$name."</a><br>
        Type: ".$itemtype."<br>
        Creator: <a href='/user/?id=".$item['creator']."'>".$creator."</a>
    </div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
}
?>
</th>
                                  </tr>
    
    <table style="margin-top: 0.8rem;" width="100%" cellspacing="0px">
    <tbody><tr>
        <th class="tablehead">Body Colors</th>
    </tr>
  </tbody><tbody><tr>
  <th class="tablebody">

  <form action="/api/updatecolors.aspx" method="POST">

    
    
<label for="head">Head:</label>
<?php echo $headSelect; ?>
<br>
<label for="larm">Left Arm:</label>
<?php echo $larmSelect; ?>
<br>
<label for="rarm">Right Arm:</label>
<?php echo $rarmSelect; ?>
<br>
<label for="torso">Torso:</label>
<?php echo $torsoSelect; ?>
<br>
<label for="lleg">Left Leg:</label>
<?php echo $llegSelect; ?>
<br>
<label for="rleg">Right Leg:</label>
<?php echo $rlegSelect; ?>
<br>
  <input type="submit" value="Save">
  </form>

<script>
function getContrastColor(hexColor) {
    var r = parseInt(hexColor.substr(1, 2), 16);
    var g = parseInt(hexColor.substr(3, 2), 16);
    var b = parseInt(hexColor.substr(5, 2), 16);
    var brightness = (r * 299 + g * 587 + b * 114) / 1000;
    return (brightness > 125) ? '#000000' : '#FFFFFF';
}
document.addEventListener('DOMContentLoaded', function() {
    var colorPreviews = document.querySelectorAll('.color-preview');
    colorPreviews.forEach(function(element) {
        var bgColor = element.style.backgroundColor;
        var textColor = getContrastColor(bgColor);
        element.style.color = textColor;
    });
});
</script>



  </th>
                                  </tr></tbody></table>
    
    
    </table>
</div>
    <div id="right">
                    <table cellspacing="0px" width="100%">
                        <tbody>
                            <tr><th class="tablehead">My Character</th></tr>
                            <tr>
                                <th class="tablebody">
                                    <iframe width="180" height="220" frameborder="0" class="margin" id="mycharacterrender" src="/api/avatar/getthumb.aspx?id=<?php echo $_USER["id"]; ?>"></iframe>
                                    <img class="margin" id="uimg" src="">
                                    <form method="post">
                                        Something wrong with your avatar? Click <a href="/My/Character.aspx" onclick="render();">here</a> to fix the problem!
                                    </form>
                                  <form action="/api/updateyear.aspx" method="POST">
<?php if ($_USER['is_render_1'] == 0) { ?>
    <input type="submit" name="render_choice" value="Enable 2015">
<?php } else { ?>
    <input type="submit" name="render_choice" value="Enable 2008">
<?php } ?>
</form>
                                </th>
                            </tr>
                        </tbody>
                    </table>
       <table cellspacing="0px" width="100%" style="margin-top: 10px;">
    <tbody><tr><th class="tablehead">Color Chooser</th></tr>
    <tr><th class="tablebody"><br>
      <button class="clickable" id="bp0" onclick="SetColorPickerActive("Head");" style="background-color:<?=$headcolor?>"></button><div class="seperator" style="height: 5px;"></div>
      <button class="clickable2" id="bp3" style="background-color:<?=$torsocolor?>"></button>
      <button class="clickable3" id="bp2" style="background-color:<?=$color_leftarm?>"></button>
      <button class="clickable2" id="bp1" style="background-color:<?=$color_rightarm?>"></button><div class="seperator" style="height: 5px;"></div>
      <button class="clickable2" id="bp5" style="background-color:<?=$color_leftleg?>"></button>
      <button class="clickable2" id="bp4" style="background-color:<?=$color_rightleg?>"></button>
     
  </tbody></table>
</div>
<div id="ColorPopupPanel" class="popupControl" style="z-index: 100; width: 260px; height: 152px;margin-top: 10%; border: solid 1px; left: 0;right: 0; top: 0; bottom: 0;margin-left: auto;margin-right: auto;">
<table id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors" cellspacing="0" border="0" style="border-width:0px;border-collapse:collapse;">
  <tr>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl00_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('00$LinkButton1', '1')" style="display:inline-block;background-color:#F2F3F2;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl01_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('01$LinkButton1', '208')" style="display:inline-block;background-color:#E5E4DE;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl02_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('02$LinkButton1', '194')" style="display:inline-block;background-color:#A3A2A4;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl03_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('03$LinkButton1', '199')" style="display:inline-block;background-color:#635F61;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl04_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('04$LinkButton1', '26')" style="display:inline-block;background-color:#1B2A34;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl05_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('05$LinkButton1', '21')" style="display:inline-block;background-color:#C4281B;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl06_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('06$LinkButton1', '24')" style="display:inline-block;background-color:#F5CD2F;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl07_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('07$LinkButton1', '226')" style="display:inline-block;background-color:#FDEA8C;height:32px;width:32px;">
      </div>
    </td>
  </tr>
  <tr>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl08_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('08$LinkButton1', '23')" style="display:inline-block;background-color:#0D69AB;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl09_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('09$LinkButton1', '107')" style="display:inline-block;background-color:#008F9B;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl10_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('10$LinkButton1', '102')" style="display:inline-block;background-color:#6E99C9;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl11_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('11$LinkButton1', '11')" style="display:inline-block;background-color:#80BBDB;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl12_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('12$LinkButton1', '45')" style="display:inline-block;background-color:#B4D2E3;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl13_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('13$LinkButton1', '135')" style="display:inline-block;background-color:#74869C;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl14_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('14$LinkButton1', '106')" style="display:inline-block;background-color:#DA8540;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl15_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('15$LinkButton1', '105')" style="display:inline-block;background-color:#E29B3F;height:32px;width:32px;">
      </div>
    </td>
  </tr>
  <tr>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl16_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('16$LinkButton1', '141')" style="display:inline-block;background-color:#27462C;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl17_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('17$LinkButton1', '28')" style="display:inline-block;background-color:#287F46;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl18_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('18$LinkButton1', '37')" style="display:inline-block;background-color:#4B974A;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl19_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('19$LinkButton1', '119')" style="display:inline-block;background-color:#A4BD46;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl20_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('20$LinkButton1', '29')" style="display:inline-block;background-color:#A1C48B;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl21_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('21$LinkButton1', '151')" style="display:inline-block;background-color:#789081;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl22_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('22$LinkButton1', '38')" style="display:inline-block;background-color:#A05F34;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl23_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('23$LinkButton1', '192')" style="display:inline-block;background-color:#694027;height:32px;width:32px;">
      </div>
    </td>
  </tr>
  <tr>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl24_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('24$LinkButton1', '104')" style="display:inline-block;background-color:#6B327B;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl25_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('25$LinkButton1', '9')" style="display:inline-block;background-color:#E8BAC7;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl26_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('26$LinkButton1', '101')" style="display:inline-block;background-color:#DA8679;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl27_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('27$LinkButton1', '5')" style="display:inline-block;background-color:#D7C599;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl28_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('28$LinkButton1', '153')" style="display:inline-block;background-color:#957976;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl29_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('29$LinkButton1', '217')" style="display:inline-block;background-color:#7C5C45;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl30_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('30$LinkButton1', '18')" style="display:inline-block;background-color:#CC8E68;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl31_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('31$LinkButton1', '125')" style="display:inline-block;background-color:#EAB891;height:32px;width:32px;">
      </div>
    </td>
  </tr>
</table>
</div>
</div>
<script>
  function setColorPickerActive(part) {
  selectedPart = part;
  document.getElementById("ColorPopupPanel").classList.remove('popupControl');
  document.getElementById("ColorPopupPanel").classList.add('popupControlShown');

  document.getElementById("ModalCloser").classList.add('modalBackground');
  document.getElementById("ModalCloser").classList.remove('modalBackgroundClosed');
}

function CloseColorChooser() {
  document.getElementById("ColorPopupPanel").classList.add('popupControl');
  document.getElementById("ColorPopupPanel").classList.remove('popupControlShown');

  document.getElementById("ModalCloser").classList.remove('modalBackground');
  document.getElementById("ModalCloser").classList.add('modalBackgroundClosed');
}
function render() {
  document.getElementById("mycharacterrender").src = "/api/render.aspx";
}
</script>

