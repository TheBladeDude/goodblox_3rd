<?php
include $_SERVER["DOCUMENT_ROOT"].'/inc/header.php';
include $_SERVER["DOCUMENT_ROOT"].'/inc/nav.php';
require_once $_SERVER["DOCUMENT_ROOT"].'/inc/config.php';

if($_SESSION["loggedin"] != 'true'){
$yourl = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
header("Location: /Login/Default.aspx?ReturnUrl=".$yourl); exit;}

$accountcode = $_USER['accountcode'];
?>
<div id="MyAccountBalanceContainer">
<div id="AboutCode" style="background-color: white;">

    <h3>What is a Account Code?</h3>
    <p>Account Code is an required code to play <a href="/Games.aspx">Multiplayer Games</a>. To get an account code you need to click "Generate new Account Code". <font color="red" size="2">Dont give away your Account code!</font></p>
  </div></div><br><br><br><br><br><br><br><br><br>
<h1>Your current Account Code is: <?php echo $accountcode; ?></h1>
<font face="Verdana" size="4"><p><a href="/my/generateaccountcode.php">Generate new Account Code</a></p></font>
<?php include $_SERVER["DOCUMENT_ROOT"].'/core/footer.php'; ?>
