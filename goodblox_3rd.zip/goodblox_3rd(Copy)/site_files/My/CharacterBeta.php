<?php
include $_SERVER["DOCUMENT_ROOT"].'/inc/header.php';
include $_SERVER["DOCUMENT_ROOT"].'/inc/nav.php';
require_once $_SERVER["DOCUMENT_ROOT"].'/inc/config.php';
if($isloggedin !== 'yes') {header('location: /login.aspx');}
  
$querytype = isset($_GET["wtype"]) ? htmlspecialchars($_GET["wtype"]) : 'hat';
$typela = 0;
if($_GET['wtype'] == "shirt"){
  $typela = 1;
}
if($_GET['wtype'] == "pants"){
  $typela = 2;
}          

$headcolor = $RobloxColorsHtml[array_search($_USER['headcolor'], $RobloxColors)];
$torsocolor = $RobloxColorsHtml[array_search($_USER['torsocolor'], $RobloxColors)];
$color_leftarm = $RobloxColorsHtml[array_search($_USER['leftarmcolor'], $RobloxColors)];
$color_rightarm = $RobloxColorsHtml[array_search($_USER['rightarmcolor'], $RobloxColors)];
$color_leftleg = $RobloxColorsHtml[array_search($_USER['leftlegcolor'], $RobloxColors)];
$color_rightleg = $RobloxColorsHtml[array_search($_USER['rightlegcolor'], $RobloxColors)];
?>
<div id="Body">
    <style>

  .clothe
  {
    width:110px;
    /*height: 200px;*/
    margin: 10px;
    text-align: left;
    
    vertical-align: top;
    display: inline-block;
    display: -moz-inline-stack;
    *display: inline;
  }
  .clothe .name {
    font-weight: bold;
  }
  .nocl
  {
    font-family: Verdana;
    font-weight: bold;
    text-align: center;
  }
  .img{
    border:none;
    height: 100%;
  }
  .imgc
  {
    border:1px solid black;
    width: 110px;
    height: 110px;
    text-align: center;
    padding: 10px;
    position: relative;
  }
  .fixed
  {
    position:absolute;
    right:0;
    top:0;
    background-color: #EEEEEE;
    border: 1px solid #555555;
    color: blue;
    font-family: Verdana;
    font-size: 10px;
    font-weight: lighter;
  }
  #left{
    width: 69%;
    float: left;
  }
  #right{
    width: 30%;
    float: right;
  }
  #Body table
  {
    border: 1px black solid;
  }
  .tablehead
  {
    font-size:16px; font-weight: bold; border-bottom:black 1px solid; width: 100%; background-color: #CCCCCC; color: #222222;
  }
  .tablebody
  {
    font-weight: lighter; background-color: transparent;font-family: Verdana;
  }
  .margin{
    margin:10px;
  }
  .clickable, .clickable3, .clickable2
  {
    border: none;
    margin:1px;
  }
  .clickable{
    width:50px;
    height: 50px;
  }
  .clickablesm{
    width:40px;
    height:40px;
    margin:5px;
  }
  .clickable2{
    width:47px;
    height: 100px;
  }
  .clickable3{
    width:100px;
    height: 100px;
  }
  .nonsbtn
  {
    font-weight:normal;
  }
  #col{
    position: fixed;
    top: 50%;
    left: 50%;
    margin-top: -105px;
    margin-left: -205px;
    width: 410px;
    height: 210px;
    z-index: 498;
    background-color: white;
    text-align: center;
    vertical-align: center;
  }
  .tablebody a {
      color:blue;
  }
  .tablebody a:hover {
      cursor:pointer;
  }
#left {
    width: 69%;
    float: left;
}
.clickable2 {
    width: 47px;
    height: 100px;
}
.clickable3 {
    width: 100px;
    height: 100px;
}
#right {
    width: 30%;
    float: right;
}
.tablebody {
    font-weight: lighter;
    background-color: transparent;
    font-family: Verdana;
}
.clickable {
    width: 50px;
    height: 50px;
}
.clickable, .clickable3, .clickable2 {
    border: none;
    margin: 1px;
}
#Body table {
    border: 1px black solid;
}
.tablehead {
    font-size: 16px;
    font-weight: bold;
    border-bottom: black 1px solid;
    width: 100%;
    background-color: #CCCCCC;
    color: #222222;
}
</style>
<script>
  $(document).ready(function () {
    function loadContent(wtype) {
      history.pushState(null, null, '/My/Character.aspx?wtype=' + wtype);

      $.ajax({
        url: '/api/user/getwardrobe.php',
        type: 'GET',
        data: { wtype: wtype },
        success: function (responseData) {
          $('#wardrobe').html(responseData);
        },
        error: function (xhr, status, error) {
          console.error('Error:', error);
        }
      });
    }

    // Function to handle link click
    function handleLinkClick(link, wtype) {
      $('.tablebody a').removeClass('bold');
      link.addClass('bold');
      loadContent(wtype);
    }

    $(document).ready(function () {
      handleLinkClick($('#btn7'), 'hat');
    });

    $(document.body).on('click', '#btn2', function (e) {
      e.preventDefault();
      handleLinkClick($('#btn2'), 'tshirt');
    });

    $(document.body).on('click', '#btn5', function (e) {
      e.preventDefault();
      handleLinkClick($('#btn5'), 'shirt');
    });

    $(document.body).on('click', '#btn6', function (e) {
      e.preventDefault();
      handleLinkClick($('#btn6'), 'pants');
    });

    $(document.body).on('click', '#btn7', function (e) {
      e.preventDefault();
      handleLinkClick($('#btn7'), 'hat');
    });

    $(document.body).on('click', '#btn8', function (e) {
      e.preventDefault();
      handleLinkClick($('#btn8'), 'face');
    });

    $(document.body).on('click', '#btn9', function (e) {
      e.preventDefault();
      handleLinkClick($('#btn9'), 'head');
    });
  });
</script>



<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

<div id="left">
  <table cellspacing="0px" width="100%" style="margin-bottom:10px;">
    <tbody><tr>
        <th class="tablehead">My Wardrobe</th>
    </tr>
   <tr>
    <td class="tablebody" style="font-size:12px; text-align: center; border-bottom: 1px solid black;">
        <a id="btn2" href="/My/Character.aspx?wtype=tshirt" onclick="makeBold('btn2')">T-Shirts</a>
        |
        <a id="btn5" href="/My/Character.aspx?wtype=shirt" onclick="makeBold('btn5')">Shirts</a>
        |
        <a id="btn6" href="/My/Character.aspx?wtype=pants" onclick="makeBold('btn6')">Pants</a>
        |
        <a id="btn7" href="/My/Character.aspx?wtype=hat" onclick="makeBold('btn7')">Hats</a>
        |
        <a id="btn8" href="?wtype=face" onclick="makeBold('btn8')">Faces</a>
        |
        <a id="btn9" href="?wtype=head" onclick="makeBold('btn9')">Heads</a>
        <br>
        <a href="/Catalog.aspx">Shop</a> |
        <a href="/my/upload/?type=<?php echo $typela; ?>">Create</a>
    </td>

<script>
    $(document).ready(function () {
        function setHatBold() {
            $('a[id^="btn"]').css('font-weight', 'normal');
            $('#btn7').css('font-weight', 'bold');
        }

        setHatBold();

        $('.tablebody a').click(function () {
            $('a[id^="btn"]').css('font-weight', 'normal');
            $(this).css('font-weight', 'bold');
        });
    });
</script>




</tr>

    <tr>
        <td class="tablebody">
            <div id="wardrobe" style="padding-left:13px;">
                  
               
                                  
                                            </div>
        <div style="clear:both;"></div>
      </td>
    </tr>
  </tbody></table><div class="seperator"></div>
  <table cellspacing="0px" width="100%">
    <tbody><tr>
        <th class="tablehead">Currently Wearing</th>
    </tr>
  </tbody><tbody><tr>
  <th class="tablebody">
  <?php
$itemsq = $db->prepare("SELECT * FROM wearing WHERE userid=:user_id");
$itemsq->bindParam(':user_id', $_USER['id'], PDO::PARAM_INT);
$itemsq->execute();

while($row = $itemsq->fetch(PDO::FETCH_ASSOC)) {
    $itemq = $db->prepare("SELECT * FROM catalog WHERE id=:item_id");
    $itemq->bindParam(':item_id', $row['itemid'], PDO::PARAM_INT);
    $itemq->execute();
    $item = $itemq->fetch(PDO::FETCH_ASSOC);

     if($item['type'] == "hat"){
  $typeala = "catalog/hats";
    }
    if($item['type'] == "shirt"){
  $typeala = "catalog/shirts";
    }
    if($item['type'] == "pants"){
  $typeala = "catalog/pants";
    }
    if($item['type'] == "head"){
  $typeala = "catalog/heads";
    }
    
   if ($item['type'] !== "face" && $item['type'] !== "tshirt") {
    $thumburl = "http://" . $sitedomain . "/img/" . $typeala . "/" . $item['id'] . ".png?rand=" . random_int(1, 999999999999999999);
} else {
    if ($item['type'] == "face") {
        $thumburl = $item['thumbnail'];
    } else {
        $thumburl = $item['filename'];
    }
}

    $iteml = $db->prepare("SELECT * FROM users WHERE id=:creator_id");
    $iteml->bindParam(':creator_id', $item['creatorid'], PDO::PARAM_INT);
    $iteml->execute();
    $user = $iteml->fetch(PDO::FETCH_ASSOC);
    
    $name = htmlspecialchars($item['name']);
    $creator = htmlspecialchars($user['username']);
    $id = (int)$item['id'];
  
    $itemtype = "Unknown";
    if($item['type'] == "hat"){
      $itemtype = "Hat";
    }
    if($item['type'] == "pants"){
      $itemtype = "Pants";
    }
    if($item['type'] == "shirt"){
      $itemtype = "Shirt";
    }
    if($item['type'] == "face"){
      $itemtype = "Face";
    }
    if($item['type'] == "tshirt"){
      $itemtype = "T-Shirt";
    }

    if($item['type'] == "hat" ){ $alawidth = "100"; } else { $alawidth = "120"; }
    if($item['type'] !== "tshirt"){
    echo "<div class='clothe' style='font-size:10.85px; display:inline-block; *display:inline; margin:5px; display: inline-block; display: -moz-inline-stack; *display: inline; vertial-align:top;'>
        <div id='".$name."' class='imgc' style='cursor:pointer;'><img class='img' width='".$alawidth."' height='120' src='".$thumburl."'>
            <div class='fixed'><a href=\"/My/characterremove.php?id=".$item['id']."&wtype=".$querytype."\">[ remove ]</a></div>
        </div>
        <a class='name' href='/Item.aspx?ID=".$id."'>".$name."</a><br>
        Type: ".$itemtype."<br>
        Creator: <a href='/User.aspx?ID=".$item['creatorid']."'>".$creator."</a>
    </div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; } else { echo "<div class='clothe' style='font-size:10.85px; display:inline-block; *display:inline; margin:5px; display: inline-block; display: -moz-inline-stack; *display: inline; vertial-align:top;'>
        <div id='".$name."' class='imgc' style='cursor:pointer;'><a id='ctl00_cphRoblox_rbxCatalog_AssetsDataList_ctl00_AssetThumbnailHyperLink' title='' href='/Item.aspx?ID=".$id."' style='display:inline-block;cursor:pointer; background-image: url(/images/tshirt.png); background-size: 120px 120px; height: 120px; width: 120px;'><img src='".$thumburl."' width='120' height='120' border='0' id='imga' alt='' blankurl='http://t6.roblox.com:80/blank-120x120.gif' style='height: 70px; width: 70px; margin-top: 27px;'></a>
            <div class='fixed'><a href=\"/My/characterremove.php?id=".$item['id']."&wtype=".$querytype."\">[ remove ]</a></div>
        </div>
        <a class='name' href='/Item.aspx?ID=".$id."'>".$name."</a><br>
        Type: ".$itemtype."<br>
        Creator: <a href='/User.aspx?ID=".$item['creatorid']."'>".$creator."</a>
    </div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; }
}
?>
</th>
                                  </tr>
    
    <table style="margin-top: 0.8rem;" width="100%" cellspacing="0px">
    <tbody><tr>
        <th class="tablehead">Body Colors</th>
    </tr>
  </tbody><tbody><tr>
  <th class="tablebody">


  <form action="/api/updatecolors.php" method="POST">
  <label for="head">Head:</label>
<select id="head" name="head">
      <option value="1"<?php if($_USER["headcolor"] == 1) {echo ' selected="selected"';} ?>>White</option>
                         <option value="208"<?php if($_USER["headcolor"] == 208) {echo ' selected="selected"';} ?>>Light stone grey</option>
                         <option value="194"<?php if($_USER["headcolor"] == 194) {echo ' selected="selected"';} ?>>Medium grey</option>
                         <option value="199"<?php if($_USER["headcolor"] == 199) {echo ' selected="selected"';} ?>>Dark stone grey</option>
                         <option value="26"<?php if($_USER["headcolor"] == 26) {echo ' selected="selected"';} ?>>Black</option>
                         <option value="21"<?php if($_USER["headcolor"] == 21) {echo ' selected="selected"';} ?>>Bright red</option>
                         <option value="24"<?php if($_USER["headcolor"] == 24) {echo ' selected="selected"';} ?>>Bright yellow</option>
                         <option value="226"<?php if($_USER["headcolor"] == 226) {echo ' selected="selected"';} ?>>Cool yellow</option>
                         <option value="23"<?php if($_USER["headcolor"] == 23) {echo ' selected="selected"';} ?>>Bright blue</option>
                         <option value="107"<?php if($_USER["headcolor"] == 107) {echo ' selected="selected"';} ?>>Bright bluish green</option>
                         <option value="102"<?php if($_USER["headcolor"] == 102) {echo ' selected="selected"';} ?>>Medium blue</option>
                         <option value="11"<?php if($_USER["headcolor"] == 11) {echo ' selected="selected"';} ?>>Pastel blue</option>
                         <option value="45"<?php if($_USER["headcolor"] == 45) {echo ' selected="selected"';} ?>>Light blue</option>
                         <option value="135"<?php if($_USER["headcolor"] == 135) {echo ' selected="selected"';} ?>>Sand blue</option>
                         <option value="106"<?php if($_USER["headcolor"] == 106) {echo ' selected="selected"';} ?>>Bright orange</option>
                         <option value="105"<?php if($_USER["headcolor"] == 105) {echo ' selected="selected"';} ?>>Br. yellowish orange</option>
                         <option value="141"<?php if($_USER["headcolor"] == 141) {echo ' selected="selected"';} ?>>Earth green</option>
                         <option value="28"<?php if($_USER["headcolor"] == 28) {echo ' selected="selected"';} ?>>Dark green</option>
                         <option value="37"<?php if($_USER["headcolor"] == 37) {echo ' selected="selected"';} ?>>Bright green</option>
                         <option value="119"<?php if($_USER["headcolor"] == 119) {echo ' selected="selected"';} ?>>Br. yellowish green</option>
                         <option value="29"<?php if($_USER["headcolor"] == 29) {echo ' selected="selected"';} ?>>Medium green</option>
                         <option value="151"<?php if($_USER["headcolor"] == 151) {echo ' selected="selected"';} ?>>Sand green</option>
                         <option value="38"<?php if($_USER["headcolor"] == 38) {echo ' selected="selected"';} ?>>Dark orange</option>
                         <option value="192"<?php if($_USER["headcolor"] == 192) {echo ' selected="selected"';} ?>>Reddish brown</option>
                         <option value="104"<?php if($_USER["headcolor"] == 104) {echo ' selected="selected"';} ?>>Bright violet</option>
                         <option value="9"<?php if($_USER["headcolor"] == 9) {echo ' selected="selected"';} ?>>Light reddish violet</option>
                         <option value="101"<?php if($_USER["headcolor"] == 101) {echo ' selected="selected"';} ?>>Medium red</option>
                         <option value="5"<?php if($_USER["headcolor"] == 5) {echo ' selected="selected"';} ?>>Brick yellow</option>
                         <option value="153"<?php if($_USER["headcolor"] == 153) {echo ' selected="selected"';} ?>>Sand red</option>
                         <option value="217"<?php if($_USER["headcolor"] == 217) {echo ' selected="selected"';} ?>>Brown</option>
                         <option value="18"<?php if($_USER["headcolor"] == 18) {echo ' selected="selected"';} ?>>Nougat</option>
                         <option value="125"<?php if($_USER["headcolor"] == 125) {echo ' selected="selected"';} ?>>Light orange</option>
      </select>
<br>
  <label for="larm">Left Arm:</label>
<select id="larm" name="larm">
      <option value="1"<?php if($_USER["leftarmcolor"] == 1) {echo ' selected="selected"';} ?>>White</option>
                         <option value="208"<?php if($_USER["leftarmcolor"] == 208) {echo ' selected="selected"';} ?>>Light stone grey</option>
                         <option value="194"<?php if($_USER["leftarmcolor"] == 194) {echo ' selected="selected"';} ?>>Medium grey</option>
                         <option value="199"<?php if($_USER["leftarmcolor"] == 199) {echo ' selected="selected"';} ?>>Dark stone grey</option>
                         <option value="26"<?php if($_USER["leftarmcolor"] == 26) {echo ' selected="selected"';} ?>>Black</option>
                         <option value="21"<?php if($_USER["leftarmcolor"] == 21) {echo ' selected="selected"';} ?>>Bright red</option>
                         <option value="24"<?php if($_USER["leftarmcolor"] == 24) {echo ' selected="selected"';} ?>>Bright yellow</option>
                         <option value="226"<?php if($_USER["leftarmcolor"] == 226) {echo ' selected="selected"';} ?>>Cool yellow</option>
                         <option value="23"<?php if($_USER["leftarmcolor"] == 23) {echo ' selected="selected"';} ?>>Bright blue</option>
                         <option value="107"<?php if($_USER["leftarmcolor"] == 107) {echo ' selected="selected"';} ?>>Bright bluish green</option>
                         <option value="102"<?php if($_USER["leftarmcolor"] == 102) {echo ' selected="selected"';} ?>>Medium blue</option>
                         <option value="11"<?php if($_USER["leftarmcolor"] == 11) {echo ' selected="selected"';} ?>>Pastel blue</option>
                         <option value="45"<?php if($_USER["leftarmcolor"] == 45) {echo ' selected="selected"';} ?>>Light blue</option>
                         <option value="135"<?php if($_USER["leftarmcolor"] == 135) {echo ' selected="selected"';} ?>>Sand blue</option>
                         <option value="106"<?php if($_USER["leftarmcolor"] == 106) {echo ' selected="selected"';} ?>>Bright orange</option>
                         <option value="105"<?php if($_USER["leftarmcolor"] == 105) {echo ' selected="selected"';} ?>>Br. yellowish orange</option>
                         <option value="141"<?php if($_USER["leftarmcolor"] == 141) {echo ' selected="selected"';} ?>>Earth green</option>
                         <option value="28"<?php if($_USER["leftarmcolor"] == 28) {echo ' selected="selected"';} ?>>Dark green</option>
                         <option value="37"<?php if($_USER["leftarmcolor"] == 37) {echo ' selected="selected"';} ?>>Bright green</option>
                         <option value="119"<?php if($_USER["leftarmcolor"] == 119) {echo ' selected="selected"';} ?>>Br. yellowish green</option>
                         <option value="29"<?php if($_USER["leftarmcolor"] == 29) {echo ' selected="selected"';} ?>>Medium green</option>
                         <option value="151"<?php if($_USER["leftarmcolor"] == 151) {echo ' selected="selected"';} ?>>Sand green</option>
                         <option value="38"<?php if($_USER["leftarmcolor"] == 38) {echo ' selected="selected"';} ?>>Dark orange</option>
                         <option value="192"<?php if($_USER["leftarmcolor"] == 192) {echo ' selected="selected"';} ?>>Reddish brown</option>
                         <option value="104"<?php if($_USER["leftarmcolor"] == 104) {echo ' selected="selected"';} ?>>Bright violet</option>
                         <option value="9"<?php if($_USER["leftarmcolor"] == 9) {echo ' selected="selected"';} ?>>Light reddish violet</option>
                         <option value="101"<?php if($_USER["leftarmcolor"] == 101) {echo ' selected="selected"';} ?>>Medium red</option>
                         <option value="5"<?php if($_USER["leftarmcolor"] == 5) {echo ' selected="selected"';} ?>>Brick yellow</option>
                         <option value="153"<?php if($_USER["leftarmcolor"] == 153) {echo ' selected="selected"';} ?>>Sand red</option>
                         <option value="217"<?php if($_USER["leftarmcolor"] == 217) {echo ' selected="selected"';} ?>>Brown</option>
                         <option value="18"<?php if($_USER["leftarmcolor"] == 18) {echo ' selected="selected"';} ?>>Nougat</option>
                         <option value="125"<?php if($_USER["leftarmcolor"] == 125) {echo ' selected="selected"';} ?>>Light orange</option>
      </select>
<br>
  <label for="rarm">Right Arm:</label>
<select id="rarm" name="rarm">
      <option value="1"<?php if($_USER["rightarmcolor"] == 1) {echo ' selected="selected"';} ?>>White</option>
                         <option value="208"<?php if($_USER["rightarmcolor"] == 208) {echo ' selected="selected"';} ?>>Light stone grey</option>
                         <option value="194"<?php if($_USER["rightarmcolor"] == 194) {echo ' selected="selected"';} ?>>Medium grey</option>
                         <option value="199"<?php if($_USER["rightarmcolor"] == 199) {echo ' selected="selected"';} ?>>Dark stone grey</option>
                         <option value="26"<?php if($_USER["rightarmcolor"] == 26) {echo ' selected="selected"';} ?>>Black</option>
                         <option value="21"<?php if($_USER["rightarmcolor"] == 21) {echo ' selected="selected"';} ?>>Bright red</option>
                         <option value="24"<?php if($_USER["rightarmcolor"] == 24) {echo ' selected="selected"';} ?>>Bright yellow</option>
                         <option value="226"<?php if($_USER["rightarmcolor"] == 226) {echo ' selected="selected"';} ?>>Cool yellow</option>
                         <option value="23"<?php if($_USER["rightarmcolor"] == 23) {echo ' selected="selected"';} ?>>Bright blue</option>
                         <option value="107"<?php if($_USER["rightarmcolor"] == 107) {echo ' selected="selected"';} ?>>Bright bluish green</option>
                         <option value="102"<?php if($_USER["rightarmcolor"] == 102) {echo ' selected="selected"';} ?>>Medium blue</option>
                         <option value="11"<?php if($_USER["rightarmcolor"] == 11) {echo ' selected="selected"';} ?>>Pastel blue</option>
                         <option value="45"<?php if($_USER["rightarmcolor"] == 45) {echo ' selected="selected"';} ?>>Light blue</option>
                         <option value="135"<?php if($_USER["rightarmcolor"] == 135) {echo ' selected="selected"';} ?>>Sand blue</option>
                         <option value="106"<?php if($_USER["rightarmcolor"] == 106) {echo ' selected="selected"';} ?>>Bright orange</option>
                         <option value="105"<?php if($_USER["rightarmcolor"] == 105) {echo ' selected="selected"';} ?>>Br. yellowish orange</option>
                         <option value="141"<?php if($_USER["rightarmcolor"] == 141) {echo ' selected="selected"';} ?>>Earth green</option>
                         <option value="28"<?php if($_USER["rightarmcolor"] == 28) {echo ' selected="selected"';} ?>>Dark green</option>
                         <option value="37"<?php if($_USER["rightarmcolor"] == 37) {echo ' selected="selected"';} ?>>Bright green</option>
                         <option value="119"<?php if($_USER["rightarmcolor"] == 119) {echo ' selected="selected"';} ?>>Br. yellowish green</option>
                         <option value="29"<?php if($_USER["rightarmcolor"] == 29) {echo ' selected="selected"';} ?>>Medium green</option>
                         <option value="151"<?php if($_USER["rightarmcolor"] == 151) {echo ' selected="selected"';} ?>>Sand green</option>
                         <option value="38"<?php if($_USER["rightarmcolor"] == 38) {echo ' selected="selected"';} ?>>Dark orange</option>
                         <option value="192"<?php if($_USER["rightarmcolor"] == 192) {echo ' selected="selected"';} ?>>Reddish brown</option>
                         <option value="104"<?php if($_USER["rightarmcolor"] == 104) {echo ' selected="selected"';} ?>>Bright violet</option>
                         <option value="9"<?php if($_USER["rightarmcolor"] == 9) {echo ' selected="selected"';} ?>>Light reddish violet</option>
                         <option value="101"<?php if($_USER["rightarmcolor"] == 101) {echo ' selected="selected"';} ?>>Medium red</option>
                         <option value="5"<?php if($_USER["rightarmcolor"] == 5) {echo ' selected="selected"';} ?>>Brick yellow</option>
                         <option value="153"<?php if($_USER["rightarmcolor"] == 153) {echo ' selected="selected"';} ?>>Sand red</option>
                         <option value="217"<?php if($_USER["rightarmcolor"] == 217) {echo ' selected="selected"';} ?>>Brown</option>
                         <option value="18"<?php if($_USER["rightarmcolor"] == 18) {echo ' selected="selected"';} ?>>Nougat</option>
                         <option value="125"<?php if($_USER["rightarmcolor"] == 125) {echo ' selected="selected"';} ?>>Light orange</option>
      </select>
<br>
  <label for="torso">Torso:</label>
<select id="torso" name="torso">
      <option value="1"<?php if($_USER["torsocolor"] == 1) {echo ' selected="selected"';} ?>>White</option>
                         <option value="208"<?php if($_USER["torsocolor"] == 208) {echo ' selected="selected"';} ?>>Light stone grey</option>
                         <option value="194"<?php if($_USER["torsocolor"] == 194) {echo ' selected="selected"';} ?>>Medium grey</option>
                         <option value="199"<?php if($_USER["torsocolor"] == 199) {echo ' selected="selected"';} ?>>Dark stone grey</option>
                         <option value="26"<?php if($_USER["torsocolor"] == 26) {echo ' selected="selected"';} ?>>Black</option>
                         <option value="21"<?php if($_USER["torsocolor"] == 21) {echo ' selected="selected"';} ?>>Bright red</option>
                         <option value="24"<?php if($_USER["torsocolor"] == 24) {echo ' selected="selected"';} ?>>Bright yellow</option>
                         <option value="226"<?php if($_USER["torsocolor"] == 226) {echo ' selected="selected"';} ?>>Cool yellow</option>
                         <option value="23"<?php if($_USER["torsocolor"] == 23) {echo ' selected="selected"';} ?>>Bright blue</option>
                         <option value="107"<?php if($_USER["torsocolor"] == 107) {echo ' selected="selected"';} ?>>Bright bluish green</option>
                         <option value="102"<?php if($_USER["torsocolor"] == 102) {echo ' selected="selected"';} ?>>Medium blue</option>
                         <option value="11"<?php if($_USER["torsocolor"] == 11) {echo ' selected="selected"';} ?>>Pastel blue</option>
                         <option value="45"<?php if($_USER["torsocolor"] == 45) {echo ' selected="selected"';} ?>>Light blue</option>
                         <option value="135"<?php if($_USER["torsocolor"] == 135) {echo ' selected="selected"';} ?>>Sand blue</option>
                         <option value="106"<?php if($_USER["torsocolor"] == 106) {echo ' selected="selected"';} ?>>Bright orange</option>
                         <option value="105"<?php if($_USER["torsocolor"] == 105) {echo ' selected="selected"';} ?>>Br. yellowish orange</option>
                         <option value="141"<?php if($_USER["torsocolor"] == 141) {echo ' selected="selected"';} ?>>Earth green</option>
                         <option value="28"<?php if($_USER["torsocolor"] == 28) {echo ' selected="selected"';} ?>>Dark green</option>
                         <option value="37"<?php if($_USER["torsocolor"] == 37) {echo ' selected="selected"';} ?>>Bright green</option>
                         <option value="119"<?php if($_USER["torsocolor"] == 119) {echo ' selected="selected"';} ?>>Br. yellowish green</option>
                         <option value="29"<?php if($_USER["torsocolor"] == 29) {echo ' selected="selected"';} ?>>Medium green</option>
                         <option value="151"<?php if($_USER["torsocolor"] == 151) {echo ' selected="selected"';} ?>>Sand green</option>
                         <option value="38"<?php if($_USER["torsocolor"] == 38) {echo ' selected="selected"';} ?>>Dark orange</option>
                         <option value="192"<?php if($_USER["torsocolor"] == 192) {echo ' selected="selected"';} ?>>Reddish brown</option>
                         <option value="104"<?php if($_USER["torsocolor"] == 104) {echo ' selected="selected"';} ?>>Bright violet</option>
                         <option value="9"<?php if($_USER["torsocolor"] == 9) {echo ' selected="selected"';} ?>>Light reddish violet</option>
                         <option value="101"<?php if($_USER["torsocolor"] == 101) {echo ' selected="selected"';} ?>>Medium red</option>
                         <option value="5"<?php if($_USER["torsocolor"] == 5) {echo ' selected="selected"';} ?>>Brick yellow</option>
                         <option value="153"<?php if($_USER["torsocolor"] == 153) {echo ' selected="selected"';} ?>>Sand red</option>
                         <option value="217"<?php if($_USER["torsocolor"] == 217) {echo ' selected="selected"';} ?>>Brown</option>
                         <option value="18"<?php if($_USER["torsocolor"] == 18) {echo ' selected="selected"';} ?>>Nougat</option>
                         <option value="125"<?php if($_USER["torsocolor"] == 125) {echo ' selected="selected"';} ?>>Light orange</option>
      </select>
<br>
  <label for="lleg">Left Leg:</label>
<select id="lleg" name="lleg">
      <option value="1"<?php if($_USER["leftlegcolor"] == 1) {echo ' selected="selected"';} ?>>White</option>
                         <option value="208"<?php if($_USER["leftlegcolor"] == 208) {echo ' selected="selected"';} ?>>Light stone grey</option>
                         <option value="194"<?php if($_USER["leftlegcolor"] == 194) {echo ' selected="selected"';} ?>>Medium grey</option>
                         <option value="199"<?php if($_USER["leftlegcolor"] == 199) {echo ' selected="selected"';} ?>>Dark stone grey</option>
                         <option value="26"<?php if($_USER["leftlegcolor"] == 26) {echo ' selected="selected"';} ?>>Black</option>
                         <option value="21"<?php if($_USER["leftlegcolor"] == 21) {echo ' selected="selected"';} ?>>Bright red</option>
                         <option value="24"<?php if($_USER["leftlegcolor"] == 24) {echo ' selected="selected"';} ?>>Bright yellow</option>
                         <option value="226"<?php if($_USER["leftlegcolor"] == 226) {echo ' selected="selected"';} ?>>Cool yellow</option>
                         <option value="23"<?php if($_USER["leftlegcolor"] == 23) {echo ' selected="selected"';} ?>>Bright blue</option>
                         <option value="107"<?php if($_USER["leftlegcolor"] == 107) {echo ' selected="selected"';} ?>>Bright bluish green</option>
                         <option value="102"<?php if($_USER["leftlegcolor"] == 102) {echo ' selected="selected"';} ?>>Medium blue</option>
                         <option value="11"<?php if($_USER["leftlegcolor"] == 11) {echo ' selected="selected"';} ?>>Pastel blue</option>
                         <option value="45"<?php if($_USER["leftlegcolor"] == 45) {echo ' selected="selected"';} ?>>Light blue</option>
                         <option value="135"<?php if($_USER["leftlegcolor"] == 135) {echo ' selected="selected"';} ?>>Sand blue</option>
                         <option value="106"<?php if($_USER["leftlegcolor"] == 106) {echo ' selected="selected"';} ?>>Bright orange</option>
                         <option value="105"<?php if($_USER["leftlegcolor"] == 105) {echo ' selected="selected"';} ?>>Br. yellowish orange</option>
                         <option value="141"<?php if($_USER["leftlegcolor"] == 141) {echo ' selected="selected"';} ?>>Earth green</option>
                         <option value="28"<?php if($_USER["leftlegcolor"] == 28) {echo ' selected="selected"';} ?>>Dark green</option>
                         <option value="37"<?php if($_USER["leftlegcolor"] == 37) {echo ' selected="selected"';} ?>>Bright green</option>
                         <option value="119"<?php if($_USER["leftlegcolor"] == 119) {echo ' selected="selected"';} ?>>Br. yellowish green</option>
                         <option value="29"<?php if($_USER["leftlegcolor"] == 29) {echo ' selected="selected"';} ?>>Medium green</option>
                         <option value="151"<?php if($_USER["leftlegcolor"] == 151) {echo ' selected="selected"';} ?>>Sand green</option>
                         <option value="38"<?php if($_USER["leftlegcolor"] == 38) {echo ' selected="selected"';} ?>>Dark orange</option>
                         <option value="192"<?php if($_USER["leftlegcolor"] == 192) {echo ' selected="selected"';} ?>>Reddish brown</option>
                         <option value="104"<?php if($_USER["leftlegcolor"] == 104) {echo ' selected="selected"';} ?>>Bright violet</option>
                         <option value="9"<?php if($_USER["leftlegcolor"] == 9) {echo ' selected="selected"';} ?>>Light reddish violet</option>
                         <option value="101"<?php if($_USER["leftlegcolor"] == 101) {echo ' selected="selected"';} ?>>Medium red</option>
                         <option value="5"<?php if($_USER["leftlegcolor"] == 5) {echo ' selected="selected"';} ?>>Brick yellow</option>
                         <option value="153"<?php if($_USER["leftlegcolor"] == 153) {echo ' selected="selected"';} ?>>Sand red</option>
                         <option value="217"<?php if($_USER["leftlegcolor"] == 217) {echo ' selected="selected"';} ?>>Brown</option>
                         <option value="18"<?php if($_USER["leftlegcolor"] == 18) {echo ' selected="selected"';} ?>>Nougat</option>
                         <option value="125"<?php if($_USER["leftlegcolor"] == 125) {echo ' selected="selected"';} ?>>Light orange</option>
      </select>
<br>
  <label for="rleg">Right Leg:</label>
<select id="rleg" name="rleg">
      <option value="1"<?php if($_USER["rightlegcolor"] == 1) {echo ' selected="selected"';} ?>>White</option>
                         <option value="208"<?php if($_USER["rightlegcolor"] == 208) {echo ' selected="selected"';} ?>>Light stone grey</option>
                         <option value="194"<?php if($_USER["rightlegcolor"] == 194) {echo ' selected="selected"';} ?>>Medium grey</option>
                         <option value="199"<?php if($_USER["rightlegcolor"] == 199) {echo ' selected="selected"';} ?>>Dark stone grey</option>
                         <option value="26"<?php if($_USER["rightlegcolor"] == 26) {echo ' selected="selected"';} ?>>Black</option>
                         <option value="21"<?php if($_USER["rightlegcolor"] == 21) {echo ' selected="selected"';} ?>>Bright red</option>
                         <option value="24"<?php if($_USER["rightlegcolor"] == 24) {echo ' selected="selected"';} ?>>Bright yellow</option>
                         <option value="226"<?php if($_USER["rightlegcolor"] == 226) {echo ' selected="selected"';} ?>>Cool yellow</option>
                         <option value="23"<?php if($_USER["rightlegcolor"] == 23) {echo ' selected="selected"';} ?>>Bright blue</option>
                         <option value="107"<?php if($_USER["rightlegcolor"] == 107) {echo ' selected="selected"';} ?>>Bright bluish green</option>
                         <option value="102"<?php if($_USER["rightlegcolor"] == 102) {echo ' selected="selected"';} ?>>Medium blue</option>
                         <option value="11"<?php if($_USER["rightlegcolor"] == 11) {echo ' selected="selected"';} ?>>Pastel blue</option>
                         <option value="45"<?php if($_USER["rightlegcolor"] == 45) {echo ' selected="selected"';} ?>>Light blue</option>
                         <option value="135"<?php if($_USER["rightlegcolor"] == 135) {echo ' selected="selected"';} ?>>Sand blue</option>
                         <option value="106"<?php if($_USER["rightlegcolor"] == 106) {echo ' selected="selected"';} ?>>Bright orange</option>
                         <option value="105"<?php if($_USER["rightlegcolor"] == 105) {echo ' selected="selected"';} ?>>Br. yellowish orange</option>
                         <option value="141"<?php if($_USER["rightlegcolor"] == 141) {echo ' selected="selected"';} ?>>Earth green</option>
                         <option value="28"<?php if($_USER["rightlegcolor"] == 28) {echo ' selected="selected"';} ?>>Dark green</option>
                         <option value="37"<?php if($_USER["rightlegcolor"] == 37) {echo ' selected="selected"';} ?>>Bright green</option>
                         <option value="119"<?php if($_USER["rightlegcolor"] == 119) {echo ' selected="selected"';} ?>>Br. yellowish green</option>
                         <option value="29"<?php if($_USER["rightlegcolor"] == 29) {echo ' selected="selected"';} ?>>Medium green</option>
                         <option value="151"<?php if($_USER["rightlegcolor"] == 151) {echo ' selected="selected"';} ?>>Sand green</option>
                         <option value="38"<?php if($_USER["rightlegcolor"] == 38) {echo ' selected="selected"';} ?>>Dark orange</option>
                         <option value="192"<?php if($_USER["rightlegcolor"] == 192) {echo ' selected="selected"';} ?>>Reddish brown</option>
                         <option value="104"<?php if($_USER["rightlegcolor"] == 104) {echo ' selected="selected"';} ?>>Bright violet</option>
                         <option value="9"<?php if($_USER["rightlegcolor"] == 9) {echo ' selected="selected"';} ?>>Light reddish violet</option>
                         <option value="101"<?php if($_USER["rightlegcolor"] == 101) {echo ' selected="selected"';} ?>>Medium red</option>
                         <option value="5"<?php if($_USER["rightlegcolor"] == 5) {echo ' selected="selected"';} ?>>Brick yellow</option>
                         <option value="153"<?php if($_USER["rightlegcolor"] == 153) {echo ' selected="selected"';} ?>>Sand red</option>
                         <option value="217"<?php if($_USER["rightlegcolor"] == 217) {echo ' selected="selected"';} ?>>Brown</option>
                         <option value="18"<?php if($_USER["rightlegcolor"] == 18) {echo ' selected="selected"';} ?>>Nougat</option>
                         <option value="125"<?php if($_USER["rightlegcolor"] == 125) {echo ' selected="selected"';} ?>>Light orange</option>
      </select>
<br>
  <input type="submit" value="Save">
  </form>





  </th>
                                  </tr></tbody></table>
    
</div>
    <div id="right">
                    <table cellspacing="0px" width="100%">
                        <tbody>
                            <tr><th class="tablehead">My Character</th></tr>
                            <tr>
                                <th class="tablebody">
                                    <iframe width="180" height="220" frameborder="0" class="margin" id="mycharacterrender" src="/api/avatar/getthumb.php?id=<?php echo $_USER["id"]; ?>"></iframe>
                                    <img class="margin" id="uimg" src="">
                                    <form method="post">
                                        Something wrong with your avatar? Click <a href="#" onclick="render();">here</a> to fix the problem!
                                    </form>
                                </th>
                            </tr>
                        </tbody>
                    </table>
      <table cellspacing="0px" width="100%" style="margin-top: 10px;">
    <tbody><tr><th class="tablehead">Color Chooser</th></tr>
    <tr><th class="tablebody"><br>

            <button class="clickable" id="bp0" onclick="SetColorPickerActive("Head");"  style="background-color:<?=$headcolor?>"></button><div class="seperator" style="height: 5px;"></div>
      <button class="clickable2" id="bp3" style="background-color:<?=$torsocolor?>" onclick="openColorPanel('torso');"></button>
      <button class="clickable3" id="bp2" style="background-color:<?=$color_leftarm?>" onclick="openColorPanel('leftarm');"></button>
      <button class="clickable2" id="bp1" style="background-color:<?=$color_rightarm?>" onclick="openColorPanel('rightarm');"></button><div class="seperator" style="height: 5px;"></div>
      <button class="clickable2" id="bp5" style="background-color:<?=$color_leftleg?>"  onclick="openColorPanel('leftleg');"></button>
      <button class="clickable2" id="bp4" style="background-color:<?=$color_rightleg?>" onclick="openColorPanel('rightleg');"></button>
    <br>Click <a href="#" disabled="disabled">here</a> to reset your character.<br></th></tr>
  </tbody></table>
</div>
<div id="ColorPopupPanel" class="popupControl" style="z-index: 100; width: 260px; height: 152px;margin-top: 10%; border: solid 1px; left: 0;right: 0; top: 0; bottom: 0;margin-left: auto;margin-right: auto;">
<table id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors" cellspacing="0" border="0" style="border-width:0px;border-collapse:collapse;">
  <tr>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl00_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('00$LinkButton1', '1')" style="display:inline-block;background-color:#F2F3F2;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl01_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('01$LinkButton1', '208')" style="display:inline-block;background-color:#E5E4DE;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl02_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('02$LinkButton1', '194')" style="display:inline-block;background-color:#A3A2A4;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl03_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('03$LinkButton1', '199')" style="display:inline-block;background-color:#635F61;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl04_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('04$LinkButton1', '26')" style="display:inline-block;background-color:#1B2A34;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl05_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('05$LinkButton1', '21')" style="display:inline-block;background-color:#C4281B;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl06_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('06$LinkButton1', '24')" style="display:inline-block;background-color:#F5CD2F;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl07_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('07$LinkButton1', '226')" style="display:inline-block;background-color:#FDEA8C;height:32px;width:32px;">
      </div>
    </td>
  </tr>
  <tr>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl08_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('08$LinkButton1', '23')" style="display:inline-block;background-color:#0D69AB;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl09_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('09$LinkButton1', '107')" style="display:inline-block;background-color:#008F9B;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl10_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('10$LinkButton1', '102')" style="display:inline-block;background-color:#6E99C9;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl11_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('11$LinkButton1', '11')" style="display:inline-block;background-color:#80BBDB;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl12_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('12$LinkButton1', '45')" style="display:inline-block;background-color:#B4D2E3;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl13_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('13$LinkButton1', '135')" style="display:inline-block;background-color:#74869C;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl14_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('14$LinkButton1', '106')" style="display:inline-block;background-color:#DA8540;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl15_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('15$LinkButton1', '105')" style="display:inline-block;background-color:#E29B3F;height:32px;width:32px;">
      </div>
    </td>
  </tr>
  <tr>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl16_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('16$LinkButton1', '141')" style="display:inline-block;background-color:#27462C;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl17_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('17$LinkButton1', '28')" style="display:inline-block;background-color:#287F46;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl18_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('18$LinkButton1', '37')" style="display:inline-block;background-color:#4B974A;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl19_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('19$LinkButton1', '119')" style="display:inline-block;background-color:#A4BD46;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl20_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('20$LinkButton1', '29')" style="display:inline-block;background-color:#A1C48B;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl21_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('21$LinkButton1', '151')" style="display:inline-block;background-color:#789081;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl22_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('22$LinkButton1', '38')" style="display:inline-block;background-color:#A05F34;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl23_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('23$LinkButton1', '192')" style="display:inline-block;background-color:#694027;height:32px;width:32px;">
      </div>
    </td>
  </tr>
  <tr>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl24_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('24$LinkButton1', '104')" style="display:inline-block;background-color:#6B327B;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl25_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('25$LinkButton1', '9')" style="display:inline-block;background-color:#E8BAC7;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl26_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('26$LinkButton1', '101')" style="display:inline-block;background-color:#DA8679;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl27_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('27$LinkButton1', '5')" style="display:inline-block;background-color:#D7C599;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl28_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('28$LinkButton1', '153')" style="display:inline-block;background-color:#957976;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl29_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('29$LinkButton1', '217')" style="display:inline-block;background-color:#7C5C45;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl30_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('30$LinkButton1', '18')" style="display:inline-block;background-color:#CC8E68;height:32px;width:32px;">
      </div>
    </td>
    <td>
      <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl31_LinkButton1" class="ColorPickerItem" onclick="SetPartColor('31$LinkButton1', '125')" style="display:inline-block;background-color:#EAB891;height:32px;width:32px;">
      </div>
    </td>
  </tr>
</table>
</div>

<script>

function setColorPickerActive(part) {
  selectedPart = part;
  document.getElementById("ColorPopupPanel").classList.remove('popupControl');
  document.getElementById("ColorPopupPanel").classList.add('popupControlShown');

  document.getElementById("ModalCloser").classList.add('modalBackground');
  document.getElementById("ModalCloser").classList.remove('modalBackgroundClosed');
}

function CloseColorChooser() {
  document.getElementById("ColorPopupPanel").classList.add('popupControl');
  document.getElementById("ColorPopupPanel").classList.remove('popupControlShown');

  document.getElementById("ModalCloser").classList.remove('modalBackground');
  document.getElementById("ModalCloser").classList.add('modalBackgroundClosed');
}

  let lastRenderTime = 0;

  function render() {
    const currentTime = Date.now();

    if (currentTime - lastRenderTime < 3000) {
      alert("Please wait at least 3 seconds between render requests.");
      return;
    }
    lastRenderTime = currentTime;
    document.getElementById("mycharacterrender").src = "/api/render";
  }
</script>

