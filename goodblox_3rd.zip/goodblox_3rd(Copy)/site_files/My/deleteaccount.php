<?php
include($_SERVER['DOCUMENT_ROOT']."/inc/config.php");
$banq = mysqli_query($link, "UPDATE `users` SET `bantype` = 'Ban', `banreason` = 'Account deleted due to your request. Thanks for playing GOODBLOX. Goodbye!' WHERE `users`.`username` = '".$_USER["username"]."'; ") or die(mysqli_error($link));
header('location: /');
?>