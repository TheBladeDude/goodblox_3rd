<?php
include($_SERVER["DOCUMENT_ROOT"]."/inc/header.php");
include($_SERVER["DOCUMENT_ROOT"]."/inc/nav.php");
require_once($_SERVER["DOCUMENT_ROOT"]."/inc/config.php");
$id = $_GET["id"];
$gameq = mysqli_query($link, "SELECT * FROM games WHERE id='".$id."'") or die(mysqli_error($link));
$game = mysqli_fetch_assoc($gameq);
$creatorq = mysqli_query($link, "SELECT * FROM users WHERE id='".$game['creator_id']."'") or die(mysqli_error($link));
$creator = mysqli_fetch_assoc($creatorq);
if($creator['id'] !== $_USER['id']) {
    header('Location: /');
    exit;
}

  if($_SESSION["loggedin"] != 'true'){
$yourl = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
header("Location: /Login/Default.aspx?ReturnUrl=".$yourl); exit;}
  
if($_SERVER["REQUEST_METHOD"] == 'POST') {
    $desiredblurb = $_POST["desc"];
    $desiredblurb = str_replace("'","\'",$desiredblurb);
   $name = $_POST["name"];
    $name = str_replace("'","\'",$name);
     $ip = $_POST["ip"];
    $ip = str_replace("'","\'",$ip);
     $port = $_POST["port"];
    $port = str_replace("'","\'",$port);
  if($_POST['access'] == 'public') {$type = 'public';} elseif($_POST['access'] == 'locked') {$type = 'friends';}
    $sql = "UPDATE `games` SET `description` = '".$desiredblurb."', `name` = '".$name."',`ip` = '".$ip."',`port` = '".$port."', `State` = '".$type."', `thumbnail` = '".$okthing."' WHERE `games`.`id` = ".$game["id"].";";
    mysqli_query($link, $sql);
  die("<div id='Body'>
          
  <div class='MessageContainer'>
        <div id='MessagePane'>
      <div id='ctl00_cphRoblox_pConfirmation'>
        <div id='Confirmation'>
          <h3>System</h3>
          <div id='Message'><span id='ctl00_cphRoblox_lConfirmationMessage'>You have successful updated your game ".$game['name'].".</span></div>
          <div class='Buttons'><a id='ctl00_cphRoblox_lbContinue' class='Button' href='/my/configureplace.php?id=".$game['id']."'>Continue</a></div>
        </div>
      
</div>
    </div>
    <div style='clear: both;'></div>
  </div>

        </div>");
}


?>
<div id="Body">
          
  <form method="POST">
  <div id="ConfigurePlaceContainer">
    <h2>Configure Place</h2>
    
    <div id="PlaceName">
      <span id="ctl00_cphRoblox_lName" class="Label">Name:</span><br>
      <input name="name" type="text" value="<?php echo $game["name"];?>" maxlength="50" id="ctl00_cphRoblox_tbName" class="TextBox">
    </div>
    
    <div id="PlaceThumbnail"><a id="ctl00_cphRoblox_rbxPlaceThumbnail" disabled="disabled" supportsalphachannel="False" title="<?php echo $game["name"];?>" onclick="return false" style="display:inline-block;height:230px;width:420px;"><img src="/thumbs/index.php?id=<?=$game['id'];?>" width="420" height="230" border="0" alt="<?php echo $game['name']; ?>" onerror="this.onerror=null;this.src='/images/unavail-160x100.png';"></a>
      </div><br>
    <div id="PlaceDescription">
      <span id="ctl00_cphRoblox_lDescription" class="Label">Description:</span><br>
      <textarea name="desc" rows="2" cols="20" id="ctl00_cphRoblox_tbDescription" class="MultilineTextBox" style="height:150px;"><?php echo $game["description"];?></textarea>
    </div>
        
        <div id="PlaceName">
      <span id="ctl00_cphRoblox_lName" class="Label">IP:</span><br>
      <input name="ip" type="text" value="<?php echo $game["ip"];?>" maxlength="50" id="ctl00_cphRoblox_tbName" class="TextBox">
    </div>
         <div id="PlaceName">
      <span id="ctl00_cphRoblox_lName" class="Label">Port:</span><br>
      <input name="port" type="text" value="<?php echo $game["port"];?>" maxlength="50" id="ctl00_cphRoblox_tbName" class="TextBox">
    </div>
    <div id="PlaceReset">
      <div id="ctl00_cphRoblox_pPlaceTemplatesPopUp" class="popupControl" style="width:400px;">
  
        <div id="ctl00_cphRoblox_upResetPlace">
    
            <div align="right">
              <a id="ctl00_cphRoblox_lbClosePopUp" class="PopUpOption" href="#">[ close window ]</a>
            </div>
            <div class="PopUpInstruction">To reset your place, click an image below:</div>
            <table id="ctl00_cphRoblox_dlPlaceTemplates" cellspacing="0" cellpadding="10" align="Center" border="0" style="border-collapse:collapse;">
      <tbody><tr>
        <td align="center" valign="middle" style="color:#003399;background-color:White;">
                <a id="ctl00_cphRoblox_dlPlaceTemplates_ctl00_rbxPlaceTemplateThumbnail" supportsalphachannel="false" title="Happy Home in Robloxia" onclick="javascript:__doPostBack('ctl00$cphRoblox$dlPlaceTemplates$ctl00$rbxPlaceTemplateThumbnail','')" style="display:inline-block;height:70px;width:120px;cursor:pointer;"><img src="http://t6.roblox.com:80/Place-120x70-a2450b0aa54744d7ab199b4ee96f1fc5.Png" border="0" id="img" alt="Happy Home in Robloxia"></a><br>
                <span id="ctl00_cphRoblox_dlPlaceTemplates_ctl00_lPlaceTemplateName">Happy Home in Robloxia</span>
              </td><td align="center" valign="middle" style="color:#003399;background-color:White;">
                <a id="ctl00_cphRoblox_dlPlaceTemplates_ctl02_rbxPlaceTemplateThumbnail" supportsalphachannel="false" title="Starting BrickBattle Map" onclick="javascript:__doPostBack('ctl00$cphRoblox$dlPlaceTemplates$ctl02$rbxPlaceTemplateThumbnail','')" style="display:inline-block;height:70px;width:120px;cursor:pointer;"><img src="http://t4.roblox.com:80/Place-120x70-d573a1bb3ee3bc14f535026e8c234671.Png" border="0" id="img" alt="Starting BrickBattle Map"></a><br>
                <span id="ctl00_cphRoblox_dlPlaceTemplates_ctl02_lPlaceTemplateName">Starting BrickBattle Map</span>
              </td>
      </tr><tr>
        <td align="center" valign="middle" style="color:#003399;background-color:White;">
                <a id="ctl00_cphRoblox_dlPlaceTemplates_ctl01_rbxPlaceTemplateThumbnail" supportsalphachannel="false" title="Empty Baseplate" onclick="javascript:__doPostBack('ctl00$cphRoblox$dlPlaceTemplates$ctl01$rbxPlaceTemplateThumbnail','')" style="display:inline-block;height:70px;width:120px;cursor:pointer;"><img src="http://t1.roblox.com:80/Place-120x70-a67675f3c46d54fa166edaf4e2e8d6e2.Png" border="0" id="img" alt="Empty Baseplate"></a><br>
                <span id="ctl00_cphRoblox_dlPlaceTemplates_ctl01_lPlaceTemplateName">Empty Baseplate</span>
              </td><td></td>
      </tr>
    </tbody></table>
            
            
          
  </div>
      
</div>
    <fieldset title="Access">        <legend>Access</legend>        <div class="Suggestion">
          This determines who can access your place.
        </div><div class="AccessRow" style="padding: 10px 4px 10px 4px;width:auto;">
       <input id="access" type="radio" name="access" value="public"  <?php if($game['State'] == "public"){ ?>checked="" <?php } ?>tabindex="6"><label><img src="/images/public.png"> Public: Anybody can visit my place</label><br>     
      <input id="access" type="radio" name="access" value="locked" <?php if($game['State'] == "friends"){?>checked="" <?php } ?>tabindex="6"><label><img src="/images/locked.png"> Private:  Only my friends can visit my place</label><br>
        </div>
      </fieldset>
      <fieldset title="Reset Place">
        <legend>Reset Place</legend>
        <div class="Suggestion">
          Only do this if you want to reset your place to one of our starting templates.  This will cause you to lose any changes you have made and cannot be un-done.
        </div>
        <div class="ResetPlaceRow">
          <div id="ctl00_cphRoblox_pResetPlace" class="Button" style="width:80px;">
  
            Reset Place
          
</div>
        </div>
      </fieldset>
          <fieldset title="Delete Place">
        <legend>Delete Place</legend>
        <div class="Suggestion">
          Only do this if you want to delete your place.  This will cause you to lose any changes you have made and cannot be un-done.
        </div>
        <div class="ResetPlaceRow">
          <a tabindex="4" class="Button" href="delplace.php?id=<?php echo $game["id"];?>">Delete Place</a>
        </div>
      </fieldset>
      
        </div>
    <br>
    <center>
        <div class="Buttons">
     <input id="Submit" tabindex="4" class="Button" type="submit" name="descupd" value="Update">&nbsp;<a id="ctl00_cphRoblox_lbCancel" class="Button" href="javascript:__doPostBack('ctl00$cphRoblox$lbCancel','')">Cancel</a>
        </div>
      </center>
  </div>

        </div>
</form>

  <?php
 include($_SERVER["DOCUMENT_ROOT"]."/inc/footer.php");
        ?>