<?php include '../inc/header.php';  
  include '../inc/nav.php';
  if($_SESSION["loggedin"] != 'true'){
$yourl = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
header("Location: /Login/Default.aspx?ReturnUrl=".$yourl); exit;}
  ?>
<div id="Body">
<script>
    function remove(id)
    {
        $("#adimgconfirmremove").attr("src", $("#adimg" + id).attr("src"));
        $("#rab").attr("value", id);
        $("#confirmAdRemovalFade").show();
    }
</script>
<div id="confirmAdRemovalFade" style="display: none;position: fixed;z-index: 1;left: 0;top: 0;width: 100%;height: 100%;overflow: auto;background-color: rgba(100,100,100,0.25);">
    <div id="confirmAdRemoval" class="anim" style="max-width: 325px; position: absolute; top: 50%; left: 50%; transform: translateX(-50%) translateY(-50%);">
        <div style="background-color: #FFFFE0; border:3px solid gray; box-shadow: black 5px 5px;">
            <form method="post" id="verifybid" style="margin: 1.5em;">
                <h2>Remove Ad:</h2>
                <p>Are you sure you want to delete this ad?</p>
                <img style="max-width:275px; max-height:275px; display:block; margin:auto;" id="adimgconfirmremove">
                <br>
                <button type="submit" name="removead" id="rab" class="MediumButton" style="width:100%;" disabled="">Remove</button>
                <br><br>
                <input type="button" value="Cancel" onclick="$('#confirmAdRemovalFade').hide();" class="MediumButton" style="width:100%;">
            </form>
        </div>
    </div>
</div>
<font face="Verdana" size="small">For a detailed explanation of how advertising on <?=$sitename?> works, check out the <a href="#">How Advertising Works</a> article in the help section.
</font>
<br>
<br>
You do not have any ads. Go and create some!                </div>
<?php include '../inc/footer.php'; ?>
