<?php
  include'inc/db.php';
  require_once'inc/config.php';
  ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Me</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #ff9900;
            padding: 20px;
            text-align: center;
        }
        header h1 {
            margin: 0;
            color: white;
        }
        nav {
            background-color: #333;
            color: white;
            padding: 10px;
        }
        nav a {
            color: white;
            text-decoration: none;
            margin: 0 10px;
        }
        nav a:hover {
            text-decoration: underline;
        }
        main {
            padding: 20px;
        }
        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <header>
        <h1>TheBladeDude</h1>
    </header>
    <nav>
        <a href="https://www.godb.3d.tc/Default.aspx">Back</a>
        <a href="#">My Discord Servers</a>
        <a href="https://www.brick-hall.xyz/">Brick Hall</a>
        <a href="https://www.godb.3d.tc/Default.aspx">Goodblox</a>
        <a href="#">My Discord</a>
        <span style="float:right;">Welcome, <?php echo $username; ?>!</span>
    </nav>
    <main>
        <h2>Welcome to My Website People</h2>
        <p>Im TheBladeDude And yeah</p>
        <p>Ok thanks</p>
    </main>
    <footer>
        <p>&copy; Goodblox Corporation. All rights reserved.</p>
    </footer>
</body>
</html>
