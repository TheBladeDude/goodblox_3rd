<?php
include $_SERVER["DOCUMENT_ROOT"].'/inc/header.php';
include $_SERVER["DOCUMENT_ROOT"].'/inc/nav.php';
require_once $_SERVER["DOCUMENT_ROOT"].'/inc/config.php';
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?? 0;
if($isloggedin !== 'yes') {header('location: /login.aspx');}
if($_SERVER["REQUEST_METHOD"] == 'POST') {
   $content = filter_input(INPUT_POST, 'content', FILTER_SANITIZE_STRING);
    $sql = "INSERT INTO comments (id, userid, assetid, content, time_posted) VALUES (NULL, '".$_USER['id']."', '".$id."', '".$content."', ".time().")";
    if ($conn->query($sql) === TRUE) {
      echo "Succesfully posted a comment!";
      header("Location: Item.aspx?id=$id");

    } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
die("<script>document.location = \"Item.aspx?id=$id\"</script>");
?>