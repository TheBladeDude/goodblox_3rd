<?php include('include.php'); ?>
<h1> Welcome to the Admin Rules. (SITE) </h1>
<b> WARNING: YOU NEED TO READ THIS RULE BEFORE YOURE MESSING SOMETHING, VETERANS CAN EXIT THIS PAGE. </b>
<h1> First off, use the alerts for an Real reason, not for making jokes & others. Only trusted members can use the Alerts as a fun or a joke. </h1>
<h1> Banning an innocent player will get an permanent warning, the selected user will be unbanned, if a user is doing a shit, give a reason then ban them or others etc. </h1>
<h1> You, do need to take it serious when you turn on maitentance or shutting down, doing it for complete no reason will have admin perms removed for one day, and given back, otherwise if you do it again your admin will be removed forever and you will get an warning for it. </h1>
<?php include('finclude.php'); ?>