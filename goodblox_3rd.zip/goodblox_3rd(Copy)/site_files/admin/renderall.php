<?php include('include.php'); ?>
<iframe id="renderEmbed" src="/api/randomrender.php" width="100%" height="500px"></iframe>

<script>
function reloadEmbed() {
    var iframe = document.getElementById('renderEmbed');
    iframe.contentWindow.location.reload(true);
}

function checkRedirect() {
    var iframe = document.getElementById('renderEmbed');
    var iframeUrl = iframe.contentWindow.location.href;

    if (iframeUrl.indexOf('/api/randomrender.php') === -1) {
        reloadEmbed();
    }
}

function initAutoReload() {
    setInterval(checkRedirect, 2000);
}

window.onload = initAutoReload;

  </script>

<?php include('finclude.php'); ?>