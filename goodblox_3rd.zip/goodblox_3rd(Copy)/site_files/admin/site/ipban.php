<?php
echo'in order to ip ban someone, Ask TheBladeDude And Tell The Person If He Did Something VERY Bad, Send Him The User IP and he will get ip banned.';

$bannedIPs = ['47.221.57.19', '192.168.0.1'];


$userIP = $_SERVER['REMOTE_ADDR'];
if (in_array($userIP, $bannedIPs)) {
    header("Location: google.com");
    exit();
}

?>