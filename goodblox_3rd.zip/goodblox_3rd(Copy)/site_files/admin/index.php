<?php require_once($_SERVER['DOCUMENT_ROOT'].'/inc/header.php');
 require_once($_SERVER['DOCUMENT_ROOT'].'/inc/nav.php'); 


if ($_USER['USER_PERMISSIONS'] !== "Administrator") {
    
    $sql = "INSERT INTO skids (user_id, action, log_timestamp) VALUES (:user_id, :action, NOW())";

    $user_id = $_USER['id'];
    $action = "admin";

    $stmt = $db->prepare($sql);
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->bindParam(':action', $action, PDO::PARAM_STR);

    $stmt->execute();
    
    header("Location: /");
    exit; 
}


?>
<style>
    #Item {
        font-family: Verdana, Sans-Serif;
        padding: 10px;
    }

    #ItemContainer {
        background-color: #eee;
        border: solid 1px #555;
        color: #555;
        margin: 0 auto;
        width: 620px;
    }

    #Actions {
        background-color: #fff;
        border-bottom: dashed 1px #555;
        border-left: dashed 1px #555;
        border-right: dashed 1px #555;
        clear: left;
        float: left;
        padding: 5px;
        text-align: center;
        min-width: 0;
        position: relative;
    }

    .PlayGames {
        background-color: #ccc;
        border: dashed 1px Green;
        color: Green;
        float: right;
        margin-top: 10px;
        padding: 10px 5px;
        text-align: right;
        width: 325px;
    }
</style>
<br>
<div id="ItemContainer">
    <h2>Admin Panel</h2>
    <div id="Item">
        
<center>

<h3>Content</h3>
<a href="/admin/content/items.php">Accept Items (N/A)</a>
<br>
<a href="/admin/content/reports.php">Manage Reports (N/A)</a>

<br>
<br>

<h3>Users</h3>
<a href="/admin/site/findalts.php">Find Alts</a>
<br>
<a href="/admin/site/ban.php">Moderate User</a>
<br>
<a href="/admin/site/unban.php">Unmoderate User</a>
<br>
<a href="/admin/users/givebuildersclub.php">Give Builders Club</a>
<br>
<a href="/admin/users/currencygift.php">Give Currency</a>
<br>
<a href="/admin/users/ipban.php">IP Ban</a>
<br>

<br>
<br>

<h3>Site</h3>
<a href="/admin/site/site_alerts/sitealerts.php">Manage Site Alerts</a>
<br>
<a href="/admin/site/maintenance.php">Manage Maintenance</a>
<br>
<a href="/admin/site/giveadmin.php">Manage Admin Access</a>
<br>
<a href="/admin/security/servercontroller.php">Server Controller(Not Working)</a>
<br>
<?php
  $sql = "SELECT COUNT(*) AS unresolved_count FROM skids WHERE resolved = 'no'";    $stmt = $db->query($sql);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<a href="/admin/security/security.php">Manage Security Issues (<?=number_format($result['unresolved_count']);?>)</a>


</center>

        </div>

    </div>

<?php require_once($_SERVER['DOCUMENT_ROOT'].'/inc/footer.php'); ?>
