<?php include($_SERVER["DOCUMENT_ROOT"]."/inc/footer.php");
?>