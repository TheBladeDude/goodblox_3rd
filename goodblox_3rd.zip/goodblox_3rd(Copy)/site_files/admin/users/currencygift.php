<?php include($_SERVER["DOCUMENT_ROOT"]."/admin/include.php"); ?>
<center>
<a href="/admin/index.php"><h1 style="color: black;">< Back</h1></a>
    <h1>Choose Currency</h1>
    <a style="color: blue;" href="/admin/users/robuxcurrencygift.php">GOODBUX</a><br>
    <a style="color: blue;" href="/admin/users/tixcurrencygift.php">TICKETS</a><br>
</center>
<?php  include($_SERVER["DOCUMENT_ROOT"]."/admin/finclude.php"); ?>