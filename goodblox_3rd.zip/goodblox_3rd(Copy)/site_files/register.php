<?php
header('location: /Login/NewAge.aspx');  
?>