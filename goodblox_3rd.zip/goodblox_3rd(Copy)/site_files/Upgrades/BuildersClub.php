<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php
  require_once($_SERVER["DOCUMENT_ROOT"]."/inc/header.php");
 require_once($_SERVER["DOCUMENT_ROOT"]."/inc/nav.php");
?>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" id="www-godb-3d-tc">
 <head>
  <title>Builders Club</title>
  <link rel="Shortcut Icon" type="image/ico" href="/favicon.ico" />
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta http-equiv="Content-Language" content="en-us" />
  <meta name="author" content="GoodBlox" />
  <meta name="description" content="GoodBlox is SAFE for gamers! GoodBlox is a FREE casual virtual world with fully constructible/desctructible 3D environments and immersive physics. Build, battle, chat, or just hang out." />
  <meta name="keywords" content="game, video game, building game, contstruction game, online game, LEGO game, LEGO, MMO, MMORPG, virtual world, avatar chat" />
  <meta name="robots" content="all">
  <meta name="theme-color" content="#FF0000" />
  <meta property="og:title" content="Builders Club" />
  <meta property="og:site_name" content="GoodBlox - We're Good" />
  <meta property="og:url" content="https://godb.3d.tc" />
  <meta property="og:description" content="GoodBlox is SAFE for gamers! GoodBlox is a FREE casual virtual world with fully constructible/desctructible 3D environments and immersive physics. Build, battle, chat, or just hang out." />
  <meta property="og:type" content="website" />
  <meta property="og:image" content="https://goodblox.xyz/resources/goodblox128.png" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js" type="text/javascript"></script>
  <script data-ad-client="ca-pub-9428704937125405" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js" type="text/javascript"></script>
 </head>
        <div id="UserBadges">
            <h4><font face="Comic sans MS" size="3">Builders Club</font></h4>
            <p style="margin-top: 15px;">This page is just for show and is non-functional</p>
            <p>We are not actually selling any form of membership or currency</p>
            <p>We apologize for any inconvenience</p>
            <div style="margin-bottom: 20px;" id="PurchaseButton">
                <a class="Button" onclick="$('#info').hide()">OK</a>
            </div>
            <table cellspacing="0" border="0" align="Center"> 
            </table>
        </div>      
    </div>
  </div>
</div>
<font face="Verdana">
  <br/><br/>
  <div id="BuildersClubContainer" style="border:1px solid black;">
  <div id="JoinBuildersClubNow"><img src="/resources/JoinBuildersClubNow.png" alt="Join Builders Club Now!" style="margin-bottom:-2px;" /></div>
  <div id="MembershipOptions">
    <div id="OneMonth">
      <div class="BuildersClubButton"><a href="#" onclick="$('#info').show()"><img src="/resources/BuyBCMonthly.png" style="border-width:0px;" /></a></div>
      <div class="Label"><a href="#" onclick="$('#info').show()">Join Monthly</a></div>
    </div>
    <div id="SixMonths">
      <div class="BuildersClubButton"><a href="#" onclick="$('#info').show()"><img src="/resources/BuyBC6Months.png" style="border-width:0px;" /></a></div>
      <div class="Label"><a href="#" onclick="$('#info').show()">Join for 6 Months</a></div>
    </div>
    <div id="TwelveMonths">
      <div class="BuildersClubButton"><a href="#" onclick="$('#info').show()"><img src="/resources/BuyBC12Months.png" style="border-width:0px;" /></a></div>
      <div class="Label"><a href="#" onclick="$('#info').show()">Join for 12 Months</a></div>
    </div>
  </div>
  <div id="WhyJoin">
    <h3>Why Join Builders Club?</h3>
    <ul id="MembershipBenefits">
      <li id="Benefit_MultiplePlaces">Create up to 10 places on a single account</li>
      <li id="Benefit_RobuxAllowance">Earn a daily income of 15 GOODBUX</li>
      <!--<li id="Benefit_SuppressAds">Never see any outside ads on GOODBLOX.XYZ</li>-->
      <li id="Benefit_ExclusiveHat">Receive the exclusive Builders Club construction hard hat</li>
    </ul>
    <p>Product is Windows-only. For more information, read our <a href="../Default.aspx">Builders Club FAQs</a>.</p>
    <h3>Not Ready Yet?</h3>
    <ul id="MembershipBenefits">
    <li id="Benefit_RobuxAllowance">You can also <a href="../Default.aspx">grab GOODBUX(soon)</a> by donating us. We will offer you some as our way of saying thank you. </li>
    <ul>
  </div>
  <div style="clear:both;"></div>
</font>
    </div>
</html></body>
      
<?php
  require_once($_SERVER["DOCUMENT_ROOT"]."/inc/footer.php"); 
?>