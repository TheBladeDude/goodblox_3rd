dofile("https://godb.3d.tc/join/guestjoinserver.php?<?php echo $_SERVER["QUERY_STRING"]; ?>&")
