<?php if($_GET['accountcode'] == 'Guest') {include('guestplay.php'); die();} ?>
dofile("https://godb.3d.tc/join/JoinServer.php?<?php echo $_SERVER["QUERY_STRING"]; ?>&")
dofile("https://godb.3d.tc/join/character.php?<?php echo $_SERVER["QUERY_STRING"]; ?>&")
