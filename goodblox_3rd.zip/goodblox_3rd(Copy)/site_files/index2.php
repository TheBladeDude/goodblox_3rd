<?php
  include 'inc/header.php';
  include 'inc/config.php';
  ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Goodblox</title>
    </head>
  <body>
    <p>test sad message</p>
    <br>
    <p>im so sad</p>
    </body>
  </html>
<?php
  include 'inc/footer.php';
  ?>