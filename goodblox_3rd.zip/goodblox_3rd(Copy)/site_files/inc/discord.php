<?php
require_once($_SERVER["DOCUMENT_ROOT"]."/inc/functionsapi.php");

// Discord Logging
if(
    !str_starts_with($_SERVER["PHP_SELF"], "/Login") &&
    !str_starts_with($_SERVER["PHP_SELF"], "/img") &&
    !str_starts_with($_SERVER["PHP_SELF"], "/Game/servers") &&
    $_SERVER["PHP_SELF"] !== "/Error.php"
) {
    try{
$content = "## Request
Logged In: **false**
Page: **{$_SERVER["REQUEST_URI"]}**
File: **{$_SERVER["PHP_SELF"]}**
Request Method: **{$_SERVER["REQUEST_METHOD"]}**
GET Parameters: **".json_encode($_GET)."**
POST Parameters: **".json_encode($_POST)."**";
        if($loggedin === "yes") {
$content = "## Request from {$_USER["username"]}
Logged In: **true**
ID: **{$_USER["id"]}**
Page: **{$_SERVER["REQUEST_URI"]}**
File: **{$_SERVER["PHP_SELF"]}**
GOODBUX: **{$_USER["robux"]}**
Tickets: **{$_USER["tickets"]}**
Request Method: **{$_SERVER["REQUEST_METHOD"]}**
GET Parameters: **".json_encode($_GET)."**
POST Parameters: **".json_encode($_POST)."**";
        }

        $msg = ["username" => $_USER["username"] ?? "Not Logged In", "content" => $content];

        $headers = array('Content-Type: application/json');

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://discord.com/api/webhooks/1208111291840073778/Gra19D0jwjUQD0Tlt_v7OrHRobpSDEyAyfEMEleI0QwRrNmJ8jv1v3aD-ra3Ih6Ks8WM");
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($msg));
        curl_exec($ch);
        curl_close($ch);
    } catch(Exception $e) {}
}