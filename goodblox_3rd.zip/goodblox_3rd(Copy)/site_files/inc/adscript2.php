<?php $imageArray = array(   
  2 => array("address" => "/images/Ads/2/1002.png"),
  3 => array("address" => "/images/Ads/2/1004.png"),
  4 => array("address" => "/images/Ads/2/1005.png"),
  5 => array("address" => "/images/Ads/2/317.png"),
  6 => array("address" => "/images/Ads/2/986.png"),
  7 => array("address" => "/images/Ads/2/997.png"),
  8 => array("address" => "/images/Ads/2/1020.png"),
  9 => array("address" => "/images/Ads/2/1019.png"),  
  10 => array("address" => "/images/Ads/2/43.png"),
  11 => array("address" => "/images/Ads/2/46.png"),
  12 => array("address" => "/images/Ads/2/47.png"),
);
?>