<?php
  require_once($_SERVER['DOCUMENT_ROOT'].'/inc/config.php');
  error_reporting(0);
//error_reporting(E_ALL);
$servername = "mysql2.serv00.com";
$username = "m2315_goodblox";
$password = "F+YEI#s!YvMKxdF6qQB-weXl6g3c7+";
$dbname = "m2315_goodblox";

$loggedin = 'no';
  try {
    $db = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $con = $db;
    $conn = $db;
    
    //echo "Connected successfully";
} catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
  
// GoodBlox Site Mode
$testing = "false"; // testing mode 2.0 if its enabled it turns off games
$securitydown = "false"; // i recommend turing this on when site got an security attack or regular security maintenance

?>

