<?php $imageArray = array(     
  2 => array("address" => "/images/Ads/1/1003.png"),
  3 => array("address" => "/images/Ads/1/983.png"),
  4 => array("address" => "/images/Ads/1/985.png"),
  5 => array("address" => "/images/Ads/1/987.png"),
  6 => array("address" => "/images/Ads/1/991.png"),
  7 => array("address" => "/images/Ads/1/992.png"),
  8 => array("address" => "/images/Ads/1/993.png"),
  9 => array("address" => "/images/Ads/1/995.png"),
  10 => array("address" => "/images/Ads/1/1012.png"),
  11 => array("address" => "/images/Ads/1/48.png"),  
  12 => array("address" => "/images/Ads/1/80.png"),  
  13 => array("address" => "/images/Ads/1/99.png"),
  14 => array("address" => "/images/Ads/1/epic52.png"),
  15 => array("address" => "/images/Ads/1/fortnute.jpg"),
  16 => array("address" => "/images/Ads/1/realfr.png"),
  17 => array("address" => "/images/Ads/1/blamerccservice.jpg"),
);
?>