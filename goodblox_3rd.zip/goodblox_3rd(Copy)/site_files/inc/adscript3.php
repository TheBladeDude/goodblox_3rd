<?php $imageArray = array(    
  2 => array("address" => "/images/Ads/3/1000.png"),
  3 => array("address" => "/images/Ads/3/1001.png"),
  4 => array("address" => "/images/Ads/3/1007.png"),
  5 => array("address" => "/images/Ads/3/984.png"),
  6 => array("address" => "/images/Ads/3/988.png"),
  7 => array("address" => "/images/Ads/3/989.png"),
  8 => array("address" => "/images/Ads/3/1010.png"),
  9 => array("address" => "/images/Ads/3/1014.png"),
  10 => array("address" => "/images/Ads/3/105.png"),
 11 => array("address" => "/images/Ads/3/imedgingsohardrn.png"),
 12 => array("address" => "/images/Ads/3/kamtapead.jpg"),
);
?>
