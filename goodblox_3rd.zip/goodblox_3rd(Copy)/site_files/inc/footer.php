<center>
<div id="Footer">
<hr/>
<p class="Legalese">
    <?=$sitename?>, "A Good Online Toy" characters, logos, names, and all related indicia are trademarks of ROBLOX Corporation, ©2009. Patents pending.<br>
<?=$sitename?> is not affliated with Lego, ROBLOX, MegaBloks, Bionicle, Pokemon, Nintendo, Lincoln Logs, Yu Gi Oh, K'nex, Tinkertoys, Erector Set, or the Pirates of the Caribbean.<br> ARrrr! 
    <br>
    Use of this site signifies your acceptance of the <a id="ctl00_rbxFooter_hlTermsOfService" href="info/TermsOfService.php">Terms and Conditions. </a>.<br/>
    <a id="ctl00_rbxFooter_hlPrivacyPolicy" href="<?php echo $siteurl; ?>/info/Privacy.php">Privacy Policy</a>
    &nbsp;|&nbsp; <a id="ctl00_rbxFooter_hlAboutUs" href="<?php echo $siteurl; ?>/info/About.php">About Us</a>    
    &nbsp;|&nbsp; <a href="mailto:realmanhitler@gmail.com">Contact Us</a> &nbsp;|&nbsp;
    <a id="ctl00_rbxFooter_hlAboutRoblox" href="https://discord.com/invite/KgYMa8eAqQ">Discord</a>
    &nbsp;|&nbsp; <a id="ctl00_rbxFooter_hlStatus" href="<?php echo $siteurl; ?>/Maintenance/status.php">Status</a>  
    <br><br>
    Based off of January 2009
        </div>
      </div>
</form>
<center>
