<?php
include 'inc/header.php';
include 'inc/nav.php';
?>
<br>
<center><h1>An Error occured! We're sorry.</h1></center>