<?php

$postData = json_encode($_POST);

$getData = json_encode($_GET);

$message = 'Received report-stats data: ' . $postData . ' and GET data: ' . $getData;

$data = json_encode(['content' => $message]);

$webhookUrl = 'https://discord.com/api/webhooks/1237783219881906177/Jh6v3AJGeBYTCWzHfOM71kenLp06ZABZ9uLJH6Jrs0aCRjCQkGLKM5w-Q7WUczhE_8R_';

$ch = curl_init($webhookUrl);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);

echo $response;

