<?php
  include'../inc/header.php';
  include'../inc/nav.php';
 ?>

<!DOCTYPE html>
<html>
 <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>GoodBlox: Server Status</title>  
  <link rel="Shortcut Icon" type="image/ico" href="/favicon.ico" />
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta http-equiv="Content-Language" content="en-us" />
  <meta name="author" content="GoodBlox" />
  <meta name="description" content="GoodBlox is SAFE for gamers! GoodBlox is a FREE casual virtual world with fully constructible/desctructible 3D environments and immersive physics. Build, battle, chat, or just hang out." />
  <meta name="keywords" content="game, video game, building game, contstruction game, online game, LEGO game, LEGO, MMO, MMORPG, virtual world, avatar chat" />
  <meta name="robots" content="all">
  <meta name="theme-color" content="#FF0000" />
  <meta property="og:title" content="GoodBlox: Server Status" />
  <meta property="og:site_name" content="GoodBlox - We're Good" />
  <meta property="og:url" content="https://goodblox.3d.tc" />
  <meta property="og:description" content="GoodBlox is SAFE for gamers! GoodBlox is a FREE casual virtual world with fully constructible/desctructible 3D environments and immersive physics. Build, battle, chat, or just hang out." />
  <meta property="og:type" content="website" />
  <meta property="og:image" content="https://goodblox.xyz/resources/goodblox128.png" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js" type="text/javascript"></script>
  <script data-ad-client="ca-pub-9428704937125405" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js" type="text/javascript"></script>
 </head>

<h2>Server Status</h2>
<ul>
 <li>WebServer: <span style="color:green;">online </span></li>
 <!-- <li>MasterServer: <span style="color:red;">offline</span></li> -->
 <li>ThumbnailServer: <span style="color:<?php if($lastRSping >= 7) { echo "red"; } else { echo "green"; } ?>;"><?php if($lastRSping >= 7) { echo "offline"; } else { echo "online"; } ?> (<?php echo (int)$itemsInRenderQueue; ?> items in queue)</span></li>
 <li>Asset Service: <span style="color:green;">online </span></li>
 <li style="display:none;">Place Validation Server: <span style="color:darkgray;">disabled</span></li>
 <li style="display:none;">Logging Service: <span style="color:darkgray;">disabled</span></li>
 <li>GameServer: <span style="color:green;">available, 0/69 games running</span></li>
</ul>
<?php
  include'../inc/footer.php';
 ?>
