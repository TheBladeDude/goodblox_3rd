<!DOCTYPE html>
<html>
 <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta property="og:title" content="Maintenance - GoodBlox" />   
   <meta property="og:description" content="GoodBlox, A Good Online Toy." />
   <meta property="og:url" content="https://www.goodblox.3d.tc/" />
     <title>GoodBlox: Maintenance</title> 
        <style type="text/css"> 
   .content {
    width: 800px;
    margin-top: 0px;
    margin-bottom: 10px;
    margin-right: auto;
    margin-left: auto;
    text-align: justify;
   }
        </style>
    </head>
    <body style="background:rgb(0,0,0); color:white;">
        <div style="width:900px;margin:auto;"> <!-- background:#fff; -->
            <img style="display:block;margin:auto;" src="/Maintenance/resources/NormalLogo.png"> 
                <div class="content"> 
                    <p style="text-align: center">&nbsp;</p>
                    <p style="text-align: center">
                        <img src="/Maintenance/resources/maintenance.jpg" id="ctl00_cphRoblox_imgRobloxTeam" alt="Offline"/>
                    </p>
                    <p style="text-align: center; font-size: 14px;font-family:sourcesans;letter-spacing: 0.2px;font-style: normal;">
                        The site is currently offline for maintenance and upgrades. Please check back soon!
                    </p>
                    <br/>
                    <br/>
                    <br/>
                    <br/>
                    <br/>
                    <br/>
                    <br/>
                    <p>
                    </p>
                </div>
                <br /><br />
                <div style="font: normal 7pt/normal Verdana, sans-serif;text-align:center;">
     <div id="Footer">
      <hr>
      <p class="Legalese">
       GoodBlox, "A Good Online Toy" characters, logos, names, and all related indicia are trademarks of 
       <a href="https://corp.roblox.com">ROBLOX Corporation</a>,
       ©2009. Patents pending.
       <br>
       GoodBlox is not affliated with Lego, ROBLOX, MegaBloks, Bionicle, Pokemon, Nintendo, Lincoln Logs, Yu Gi Oh, K'nex, Tinkertoys, Erector Set, or the Pirates of the Caribbean. ARrrr!              <br>
       Use of this site signifies your acceptance of the <a href="/info/TermsOfService.html">Terms and Conditions</a>.              <br>
       <a href="/info/Privacy.html"><b>Privacy Policy</b></a>
       &nbsp;|&nbsp; <a href="/cdn-cgi/l/email-protection#82e5edede6e0eeedfafafafafafac2f2f0edf6edecefe3ebeeace1edef">Contact Us</a> 
       &nbsp;|&nbsp; <a href="/info/About.html">About Us</a>
       &nbsp;|&nbsp; <a href="https://discord.com/invite/KgYMa8eAqQ">Discord</a>
       <br>
       <span>Based off of January 2009<br>&nbsp;</span>
      </p>
     </div>
    </div>
        </div>
        <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script type="text/javascript">
   window.window.setTimeout("window.location = \'../\'", 86400000);
        </script>
    </body>
</html>
