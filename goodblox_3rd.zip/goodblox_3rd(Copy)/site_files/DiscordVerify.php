<?php
include 'inc/header.php';
include 'inc/nav.php';
?>
<div id="Body">
<div style="font-size: 2em; border: 1px solid black; margin: auto; padding: 20px;">
<center><p>GoodBlox Discord Server Verification.</p>
Oops! Looks like you are not verified to the Discord server yet! press here to verify!
<br><br>
<a id="Cancel" tabindex="5" class="Button" href="/VerifyAcc.aspx">Verify</a>
</center>
</div></div>
<?php
include 'inc/footer.php';
?>