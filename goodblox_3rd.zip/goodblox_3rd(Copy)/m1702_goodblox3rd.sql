-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: mysql4.serv00.com
-- Generation Time: May 31, 2024 at 05:41 PM
-- Server version: 8.0.35
-- PHP Version: 8.1.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `m1702_shitdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `abuse_reports`
--

CREATE TABLE `abuse_reports` (
  `id` int NOT NULL,
  `target_id` int NOT NULL,
  `target_type` varchar(255) NOT NULL,
  `reporter` int NOT NULL,
  `comment` varchar(2048) NOT NULL,
  `time_reported` int NOT NULL,
  `status` enum('PENDING','MODERATED','IGNORED') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `achievements`
--

CREATE TABLE `achievements` (
  `id` int NOT NULL,
  `name_file` varchar(64) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(1024) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ads`
--

CREATE TABLE `ads` (
  `id` int NOT NULL,
  `adOwner` int NOT NULL,
  `adtitle` varchar(255) NOT NULL,
  `adurl` varchar(10000) NOT NULL,
  `adimg` varchar(10000) NOT NULL,
  `status` enum('stopped','running') NOT NULL,
  `moderation` enum('pending','declined','accepted') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `alerts`
--

CREATE TABLE `alerts` (
  `id` int NOT NULL,
  `text` longtext NOT NULL,
  `color` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `avatar_cache`
--

CREATE TABLE `avatar_cache` (
  `id` int NOT NULL,
  `userid` varchar(255) NOT NULL,
  `head_color` int NOT NULL,
  `torso_color` int NOT NULL,
  `leftarm_color` int NOT NULL,
  `rightarm_color` int NOT NULL,
  `leftleg_color` int NOT NULL,
  `rightleg_color` int NOT NULL,
  `hatid1` int NOT NULL,
  `hatid2` int NOT NULL,
  `hatid3` int NOT NULL,
  `faceid` int NOT NULL,
  `toolid` int NOT NULL,
  `shirtid` int NOT NULL,
  `pantsid` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bans`
--

CREATE TABLE `bans` (
  `id` int NOT NULL,
  `username` varchar(255) NOT NULL,
  `userid` int NOT NULL,
  `moderator` int NOT NULL,
  `reason` varchar(4096) NOT NULL,
  `unbantime` bigint NOT NULL,
  `ip` varchar(255) NOT NULL,
  `bantype` enum('reminder','warning','1dayban','3dayban','7dayban','14dayban','deleteaccount','hwidban','ipban') NOT NULL,
  `unbanned` tinyint(1) NOT NULL,
  `note` varchar(4096) NOT NULL DEFAULT '',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `blocked_users`
--

CREATE TABLE `blocked_users` (
  `id` int NOT NULL,
  `user_from` int NOT NULL,
  `user_to` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bodycolors`
--

CREATE TABLE `bodycolors` (
  `color_id` int NOT NULL,
  `hex_color` varchar(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `catalog`
--

CREATE TABLE `catalog` (
  `id` int NOT NULL,
  `name` varchar(255) CHARACTER SET armscii8 COLLATE armscii8_bin NOT NULL,
  `description` varchar(255) CHARACTER SET armscii8 COLLATE armscii8_bin NOT NULL,
  `thumbnail` longtext CHARACTER SET armscii8 COLLATE armscii8_bin NOT NULL,
  `creatorid` int NOT NULL,
  `creation_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `buywith` enum('tix','robux') CHARACTER SET armscii8 COLLATE armscii8_bin NOT NULL DEFAULT 'tix',
  `price` int NOT NULL,
  `type` varchar(20) CHARACTER SET armscii8 COLLATE armscii8_bin NOT NULL DEFAULT 'hat',
  `assetid` bigint NOT NULL,
  `filename` varchar(255) CHARACTER SET armscii8 COLLATE armscii8_bin NOT NULL,
  `hatmesh` varchar(255) CHARACTER SET armscii8 COLLATE armscii8_bin NOT NULL,
  `hattexture` varchar(255) CHARACTER SET armscii8 COLLATE armscii8_bin NOT NULL,
  `status` enum('Pending','Accepted','Declined') CHARACTER SET armscii8 COLLATE armscii8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `chatfilter`
--

CREATE TABLE `chatfilter` (
  `id` int NOT NULL,
  `original` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `filtered` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int NOT NULL,
  `userid` int NOT NULL,
  `assetid` int NOT NULL,
  `content` varchar(256) NOT NULL,
  `time_posted` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `currency`
--

CREATE TABLE `currency` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `value` int NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `discord_verify`
--

CREATE TABLE `discord_verify` (
  `id` int NOT NULL,
  `token` varchar(256) NOT NULL,
  `discord_id` varchar(255) NOT NULL,
  `linked_account` int DEFAULT NULL,
  `time_created` int NOT NULL,
  `unlinked` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `forum`
--

CREATE TABLE `forum` (
  `id` int NOT NULL,
  `author` int NOT NULL,
  `reply_to` int NOT NULL,
  `title` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `content` varchar(8192) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `time_posted` bigint NOT NULL,
  `category` int NOT NULL,
  `is_pinned` int NOT NULL DEFAULT '0',
  `is_locked` tinyint(1) NOT NULL DEFAULT '0',
  `is_important` tinyint(1) NOT NULL DEFAULT '0',
  `is_announcement` tinyint(1) NOT NULL DEFAULT '0',
  `bump` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `forumgroups`
--

CREATE TABLE `forumgroups` (
  `id` int NOT NULL,
  `name` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `forum_groups`
--

CREATE TABLE `forum_groups` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `sort_order` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `forum_topics`
--

CREATE TABLE `forum_topics` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(1024) NOT NULL,
  `parent` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `forum_views`
--

CREATE TABLE `forum_views` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `post_id` int NOT NULL,
  `time` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `friends`
--

CREATE TABLE `friends` (
  `id` int NOT NULL,
  `user_from` int NOT NULL,
  `user_to` int NOT NULL,
  `arefriends` int NOT NULL,
  `hash` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `gamehashes`
--

CREATE TABLE `gamehashes` (
  `id` int NOT NULL,
  `gameid` int NOT NULL,
  `userid` int NOT NULL,
  `hash` varchar(255) NOT NULL,
  `ip_address` varchar(255) NOT NULL DEFAULT 'localhost',
  `port` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `games`
--

CREATE TABLE `games` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `players` int NOT NULL,
  `creator_id` int NOT NULL,
  `thumbnail` longblob NOT NULL,
  `ip` text NOT NULL,
  `port` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `gamesvisits`
--

CREATE TABLE `gamesvisits` (
  `id` int NOT NULL,
  `gameid` int NOT NULL,
  `visitorid` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `global`
--

CREATE TABLE `global` (
  `id` int NOT NULL,
  `ShowingSiteAlert1` varchar(255) NOT NULL,
  `SiteAlert1` varchar(255) NOT NULL,
  `SiteAlert1Color` varchar(255) NOT NULL,
  `ShowingSiteAlert2` varchar(255) NOT NULL,
  `SiteAlert2` varchar(255) NOT NULL,
  `SiteAlert2Color` varchar(255) NOT NULL,
  `ShowingSiteAlert3` varchar(255) NOT NULL,
  `SiteAlert3` varchar(255) NOT NULL,
  `SiteAlert3Color` varchar(255) NOT NULL,
  `ShowingSiteAlert4` varchar(255) NOT NULL,
  `SiteAlert4` varchar(255) NOT NULL,
  `SiteAlert4Color` varchar(255) NOT NULL,
  `ShowingSiteAlert5` varchar(255) NOT NULL,
  `SiteAlert5` varchar(255) NOT NULL,
  `SiteAlert5Color` varchar(255) NOT NULL,
  `maintenanceEnabled` varchar(255) NOT NULL,
  `maintenance` varchar(255) NOT NULL,
  `shutdownEnabled` varchar(255) NOT NULL,
  `shutdown` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `invitekeys`
--

CREATE TABLE `invitekeys` (
  `id` int NOT NULL,
  `invkey` varchar(255) NOT NULL,
  `isredeemed` varchar(255) NOT NULL DEFAULT 'no',
  `creatorid` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `ip_bans`
--

CREATE TABLE `ip_bans` (
  `id` int NOT NULL,
  `ip` varchar(255) CHARACTER SET armscii8 COLLATE armscii8_bin NOT NULL DEFAULT '0.0.0.0',
  `banned_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `join_tokens`
--

CREATE TABLE `join_tokens` (
  `id` int NOT NULL,
  `token` varchar(255) NOT NULL,
  `gameid` int NOT NULL,
  `userid` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `limited_sales`
--

CREATE TABLE `limited_sales` (
  `id` int NOT NULL,
  `item_id` int NOT NULL,
  `price` int NOT NULL,
  `time` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `logins`
--

CREATE TABLE `logins` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `ip` varchar(256) NOT NULL,
  `username` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int NOT NULL,
  `user_from` int NOT NULL,
  `user_to` int NOT NULL,
  `subject` varchar(64) NOT NULL,
  `content` varchar(10000) NOT NULL,
  `datesent` int NOT NULL,
  `readfrom` tinyint(1) NOT NULL DEFAULT '0',
  `readto` tinyint(1) NOT NULL DEFAULT '0',
  `deletefrom` tinyint(1) NOT NULL DEFAULT '0',
  `deleteto` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `on_sale_limiteds`
--

CREATE TABLE `on_sale_limiteds` (
  `id` int NOT NULL,
  `item_id` int NOT NULL,
  `user_id` int NOT NULL,
  `owneditem_id` int NOT NULL,
  `price` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `owneditems`
--

CREATE TABLE `owneditems` (
  `id` int NOT NULL,
  `assetid` int NOT NULL,
  `userid` int NOT NULL,
  `type` varchar(255) NOT NULL,
  `serial` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `owned_achievements`
--

CREATE TABLE `owned_achievements` (
  `id` int NOT NULL,
  `user_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `owned_items`
--

CREATE TABLE `owned_items` (
  `id` int NOT NULL,
  `itemid` int NOT NULL,
  `ownerid` int NOT NULL,
  `type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `pageviews`
--

CREATE TABLE `pageviews` (
  `id` int NOT NULL,
  `ip` varchar(255) NOT NULL,
  `userid` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int NOT NULL,
  `txnid` varchar(255) NOT NULL,
  `payment_amount` varchar(255) NOT NULL,
  `payment_status` varchar(255) NOT NULL,
  `itemid` varchar(255) NOT NULL,
  `createdtime` varchar(255) NOT NULL,
  `userid` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `placehostrequests`
--

CREATE TABLE `placehostrequests` (
  `id` int NOT NULL,
  `gameid` int NOT NULL,
  `year` varchar(7) NOT NULL,
  `instance_id` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `placeshutdownrequests`
--

CREATE TABLE `placeshutdownrequests` (
  `id` int NOT NULL,
  `processid` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int NOT NULL,
  `user_from` int NOT NULL,
  `content` varchar(1000) NOT NULL,
  `time_posted` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `post_reactions`
--

CREATE TABLE `post_reactions` (
  `id` int NOT NULL,
  `userid` int NOT NULL,
  `postid` int NOT NULL,
  `reaction` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `renders`
--

CREATE TABLE `renders` (
  `id` int NOT NULL,
  `render_id` int NOT NULL,
  `type` varchar(255) NOT NULL,
  `version` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `id` int NOT NULL,
  `userid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `guyid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sent` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `session_tokens`
--

CREATE TABLE `session_tokens` (
  `id` int NOT NULL,
  `token` varchar(255) NOT NULL,
  `user_id` int NOT NULL,
  `ip_address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `skids`
--

CREATE TABLE `skids` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `action` enum('admin','','','') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `log_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `resolved` enum('yes','no','','') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'no'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `topics`
--

CREATE TABLE `topics` (
  `id` int NOT NULL,
  `name` longtext NOT NULL,
  `description` longtext NOT NULL,
  `category` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `referral` varchar(255) NOT NULL,
  `robux` int NOT NULL,
  `tix` int NOT NULL,
  `lastseen` int NOT NULL,
  `next_tix_reward` int NOT NULL,
  `next_bricks_award` int NOT NULL,
  `BC` enum('None','BC') NOT NULL,
  `BCExpire` date NOT NULL,
  `headcolor` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT 'Bright yellow',
  `torsocolor` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT 'Bright blue',
  `rightarmcolor` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT 'Bright yellow',
  `rightlegcolor` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT 'Br. yellowish green',
  `leftarmcolor` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT 'Bright yellow',
  `leftlegcolor` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT 'Br. yellowish green',
  `USER_PERMISSIONS` enum('None','Forum_Moderator','Administrator') NOT NULL,
  `bantype` enum('None','Reminder','Warning','1daysban','Ban') NOT NULL,
  `banreason` varchar(255) NOT NULL,
  `bandate` datetime NOT NULL,
  `unbantime` int NOT NULL,
  `blurb` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `isVerified` int NOT NULL,
  `thumbnail` longtext NOT NULL,
  `accountcode` varchar(255) NOT NULL,
  `defaultmaplocationfolder` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `defaultmapfilename` varchar(255) NOT NULL,
  `ip` varchar(5000) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '0.0.0.0',
  `joindate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_render_1` int DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `wearing`
--

CREATE TABLE `wearing` (
  `id` bigint NOT NULL,
  `userid` int NOT NULL,
  `itemid` int NOT NULL,
  `type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ads`
--
ALTER TABLE `ads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `alerts`
--
ALTER TABLE `alerts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `catalog`
--
ALTER TABLE `catalog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chatfilter`
--
ALTER TABLE `chatfilter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `forum`
--
ALTER TABLE `forum`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `forumgroups`
--
ALTER TABLE `forumgroups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `friends`
--
ALTER TABLE `friends`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `games`
--
ALTER TABLE `games`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gamesvisits`
--
ALTER TABLE `gamesvisits`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `global`
--
ALTER TABLE `global`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `owned_items`
--
ALTER TABLE `owned_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `renders`
--
ALTER TABLE `renders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `skids`
--
ALTER TABLE `skids`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `topics`
--
ALTER TABLE `topics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wearing`
--
ALTER TABLE `wearing`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ads`
--
ALTER TABLE `ads`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `alerts`
--
ALTER TABLE `alerts`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `catalog`
--
ALTER TABLE `catalog`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `chatfilter`
--
ALTER TABLE `chatfilter`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `forum`
--
ALTER TABLE `forum`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `forumgroups`
--
ALTER TABLE `forumgroups`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `friends`
--
ALTER TABLE `friends`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `games`
--
ALTER TABLE `games`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `gamesvisits`
--
ALTER TABLE `gamesvisits`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `global`
--
ALTER TABLE `global`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `owned_items`
--
ALTER TABLE `owned_items`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `renders`
--
ALTER TABLE `renders`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `skids`
--
ALTER TABLE `skids`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `topics`
--
ALTER TABLE `topics`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wearing`
--
ALTER TABLE `wearing`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
